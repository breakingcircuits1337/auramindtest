# auramind

[Edit in StackBlitz next generation editor ⚡️](https://stackblitz.com/~/github.com/breakingcircuits1337/auramind)