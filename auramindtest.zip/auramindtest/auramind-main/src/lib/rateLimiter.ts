
interface RateLimitConfig {
  windowMs: number;
  maxRequests: number;
  keyGenerator?: (request: any) => string;
  skipSuccessfulRequests?: boolean;
  skipFailedRequests?: boolean;
  skipWhenEmpty?: boolean;
}

interface RateLimitInfo {
  totalHits: number;
  totalRequests: number;
  remainingPoints: number;
  msBeforeNext: number;
  isBlocked: boolean;
}

interface RequestRecord {
  count: number;
  resetTime: number;
  firstRequest: number;
}

class RateLimiter {
  private records: Map<string, RequestRecord> = new Map();
  private config: RateLimitConfig;
  private cleanupInterval: NodeJS.Timeout | null = null;

  constructor(config: RateLimitConfig) {
    this.config = {
      keyGenerator: (req) => req.ip || 'default',
      skipSuccessfulRequests: false,
      skipFailedRequests: false,
      skipWhenEmpty: false,
      ...config
    };

    this.startCleanup();
  }

  public async isAllowed(request: any): Promise<{ allowed: boolean; info: RateLimitInfo }> {
    const key = this.config.keyGenerator!(request);
    const now = Date.now();
    
    let record = this.records.get(key);
    
    if (!record || now > record.resetTime) {
      // Create new window
      record = {
        count: 0,
        resetTime: now + this.config.windowMs,
        firstRequest: now
      };
      this.records.set(key, record);
    }

    const info: RateLimitInfo = {
      totalHits: record.count,
      totalRequests: record.count + 1,
      remainingPoints: Math.max(0, this.config.maxRequests - record.count - 1),
      msBeforeNext: record.resetTime - now,
      isBlocked: record.count >= this.config.maxRequests
    };

    if (record.count >= this.config.maxRequests) {
      return { allowed: false, info };
    }

    record.count++;
    return { allowed: true, info };
  }

  public getInfo(key: string): RateLimitInfo | null {
    const record = this.records.get(key);
    
    if (!record) {
      return null;
    }

    const now = Date.now();
    
    return {
      totalHits: record.count,
      totalRequests: record.count,
      remainingPoints: Math.max(0, this.config.maxRequests - record.count),
      msBeforeNext: Math.max(0, record.resetTime - now),
      isBlocked: record.count >= this.config.maxRequests
    };
  }

  public reset(key: string): boolean {
    return this.records.delete(key);
  }

  public resetAll(): void {
    this.records.clear();
  }

  private startCleanup(): void {
    this.cleanupInterval = setInterval(() => {
      const now = Date.now();
      
      for (const [key, record] of this.records.entries()) {
        if (now > record.resetTime) {
          this.records.delete(key);
        }
      }
    }, this.config.windowMs);
  }

  public destroy(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
    }
    this.records.clear();
  }
}

// API Rate Limiting Service
class APIRateLimitService {
  private limiters: Map<string, RateLimiter> = new Map();
  private defaultLimits = {
    // General API endpoints
    api: { windowMs: 60000, maxRequests: 100 }, // 100 requests per minute
    
    // AI/LLM endpoints (more restrictive)
    ai: { windowMs: 60000, maxRequests: 20 }, // 20 requests per minute
    
    // Authentication endpoints
    auth: { windowMs: 900000, maxRequests: 5 }, // 5 requests per 15 minutes
    
    // File upload endpoints
    upload: { windowMs: 60000, maxRequests: 10 }, // 10 uploads per minute
    
    // WebSocket connections
    websocket: { windowMs: 60000, maxRequests: 5 }, // 5 connections per minute
    
    // Analytics endpoints
    analytics: { windowMs: 60000, maxRequests: 50 }, // 50 requests per minute
  };

  constructor() {
    this.initializeLimiters();
  }

  private initializeLimiters(): void {
    for (const [key, config] of Object.entries(this.defaultLimits)) {
      this.limiters.set(key, new RateLimiter(config));
    }
  }

  public async checkLimit(
    endpoint: string, 
    request: { userId?: string; ip?: string; sessionId?: string }
  ): Promise<{ allowed: boolean; info: RateLimitInfo }> {
    const limiter = this.limiters.get(endpoint);
    
    if (!limiter) {
      // If no specific limiter, use general API limiter
      const generalLimiter = this.limiters.get('api');
      return generalLimiter ? await generalLimiter.isAllowed(request) : { 
        allowed: true, 
        info: {
          totalHits: 0,
          totalRequests: 1,
          remainingPoints: 999,
          msBeforeNext: 0,
          isBlocked: false
        }
      };
    }

    return await limiter.isAllowed(request);
  }

  public addCustomLimiter(name: string, config: RateLimitConfig): void {
    this.limiters.set(name, new RateLimiter(config));
  }

  public removeLimiter(name: string): boolean {
    const limiter = this.limiters.get(name);
    if (limiter) {
      limiter.destroy();
      return this.limiters.delete(name);
    }
    return false;
  }

  public getLimiterInfo(endpoint: string, key: string): RateLimitInfo | null {
    const limiter = this.limiters.get(endpoint);
    return limiter ? limiter.getInfo(key) : null;
  }

  public resetLimiter(endpoint: string, key?: string): boolean {
    const limiter = this.limiters.get(endpoint);
    if (!limiter) return false;

    if (key) {
      return limiter.reset(key);
    } else {
      limiter.resetAll();
      return true;
    }
  }

  public getAllStats(): Record<string, any> {
    const stats: Record<string, any> = {};
    
    for (const [name, limiter] of this.limiters.entries()) {
      stats[name] = {
        activeKeys: (limiter as any).records.size,
        config: (limiter as any).config
      };
    }
    
    return stats;
  }

  public destroy(): void {
    for (const limiter of this.limiters.values()) {
      limiter.destroy();
    }
    this.limiters.clear();
  }
}

// Client-side rate limiting for API calls
class ClientRateLimiter {
  private queues: Map<string, Array<{ resolve: Function; reject: Function; request: Function }>> = new Map();
  private timers: Map<string, NodeJS.Timeout> = new Map();
  private delays: Map<string, number> = new Map();

  public async throttle<T>(
    key: string,
    request: () => Promise<T>,
    delayMs: number = 1000
  ): Promise<T> {
    return new Promise((resolve, reject) => {
      const queue = this.queues.get(key) || [];
      queue.push({ resolve, reject, request });
      this.queues.set(key, queue);

      if (queue.length === 1) {
        this.processQueue(key, delayMs);
      }
    });
  }

  private async processQueue(key: string, delayMs: number): Promise<void> {
    const queue = this.queues.get(key);
    if (!queue || queue.length === 0) return;

    const { resolve, reject, request } = queue.shift()!;

    try {
      const result = await request();
      resolve(result);
    } catch (error) {
      reject(error);
    }

    // Schedule next request
    if (queue.length > 0) {
      const timer = setTimeout(() => {
        this.processQueue(key, delayMs);
      }, delayMs);
      
      this.timers.set(key, timer);
    } else {
      this.queues.delete(key);
      this.timers.delete(key);
    }
  }

  public getQueueLength(key: string): number {
    return this.queues.get(key)?.length || 0;
  }

  public clearQueue(key: string): void {
    const timer = this.timers.get(key);
    if (timer) {
      clearTimeout(timer);
      this.timers.delete(key);
    }
    
    const queue = this.queues.get(key);
    if (queue) {
      queue.forEach(({ reject }) => reject(new Error('Queue cleared')));
      this.queues.delete(key);
    }
  }

  public destroy(): void {
    for (const timer of this.timers.values()) {
      clearTimeout(timer);
    }
    
    for (const queue of this.queues.values()) {
      queue.forEach(({ reject }) => reject(new Error('Rate limiter destroyed')));
    }
    
    this.queues.clear();
    this.timers.clear();
  }
}

// Middleware function for API calls
export function withRateLimit<T extends any[], R>(
  fn: (...args: T) => Promise<R>,
  key: string,
  delayMs: number = 1000
): (...args: T) => Promise<R> {
  return (...args: T) => {
    return clientRateLimiter.throttle(key, () => fn(...args), delayMs);
  };
}

// Export instances
export const apiRateLimitService = new APIRateLimitService();
export const clientRateLimiter = new ClientRateLimiter();

// Utility function to create rate-limited API calls
export function createRateLimitedAPI(baseURL: string, limits: Record<string, number> = {}) {
  const defaultLimits = {
    GET: 1000,
    POST: 2000,
    PUT: 2000,
    DELETE: 3000,
    ...limits
  };

  return {
    async request<T>(
      method: string,
      endpoint: string,
      data?: any,
      options: RequestInit = {}
    ): Promise<T> {
      const delay = defaultLimits[method.toUpperCase()] || 1000;
      
      return clientRateLimiter.throttle(
        `${method}:${endpoint}`,
        async () => {
          const response = await fetch(`${baseURL}${endpoint}`, {
            method,
            headers: {
              'Content-Type': 'application/json',
              ...options.headers
            },
            body: data ? JSON.stringify(data) : undefined,
            ...options
          });

          if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
          }

          return response.json();
        },
        delay
      );
    },

    get<T>(endpoint: string, options?: RequestInit): Promise<T> {
      return this.request<T>('GET', endpoint, undefined, options);
    },

    post<T>(endpoint: string, data?: any, options?: RequestInit): Promise<T> {
      return this.request<T>('POST', endpoint, data, options);
    },

    put<T>(endpoint: string, data?: any, options?: RequestInit): Promise<T> {
      return this.request<T>('PUT', endpoint, data, options);
    },

    delete<T>(endpoint: string, options?: RequestInit): Promise<T> {
      return this.request<T>('DELETE', endpoint, undefined, options);
    }
  };
}
