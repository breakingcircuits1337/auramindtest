
import { supabase } from './supabase';
import { ENV_CONFIG } from './env';

export interface UserProfile {
  id: string;
  email: string;
  full_name?: string;
  avatar_url?: string;
  preferences: {
    theme: 'light' | 'dark';
    notifications: boolean;
    voice_enabled: boolean;
    timezone: string;
  };
  created_at: string;
  updated_at: string;
}

export interface UserData {
  tasks: any[];
  reminders: any[];
  calendar_events: any[];
  analytics_data: any;
  ai_context: any[];
  voice_recordings: string[];
}

class DatabaseService {
  private userId: string | null = null;

  async initialize() {
    if (!ENV_CONFIG.hasSupabase) {
      console.warn('Supabase not configured, falling back to localStorage');
      return false;
    }

    const { data: { user } } = await supabase.auth.getUser();
    this.userId = user?.id || null;
    return !!this.userId;
  }

  // User Profile Management
  async getUserProfile(): Promise<UserProfile | null> {
    if (!this.userId || !ENV_CONFIG.hasSupabase) {
      return this.getLocalProfile();
    }

    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('id', this.userId)
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error fetching profile:', error);
      return this.getLocalProfile();
    }
  }

  async updateUserProfile(profile: Partial<UserProfile>): Promise<boolean> {
    if (!this.userId || !ENV_CONFIG.hasSupabase) {
      return this.updateLocalProfile(profile);
    }

    try {
      const { error } = await supabase
        .from('user_profiles')
        .upsert({
          id: this.userId,
          ...profile,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;
      
      // Also update local cache
      this.updateLocalProfile(profile);
      return true;
    } catch (error) {
      console.error('Error updating profile:', error);
      return this.updateLocalProfile(profile);
    }
  }

  // User Data Synchronization
  async syncUserData(data: Partial<UserData>): Promise<boolean> {
    if (!this.userId || !ENV_CONFIG.hasSupabase) {
      return this.saveLocalData(data);
    }

    try {
      const { error } = await supabase
        .from('user_data')
        .upsert({
          user_id: this.userId,
          ...data,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;
      
      // Update local cache
      this.saveLocalData(data);
      return true;
    } catch (error) {
      console.error('Error syncing data:', error);
      return this.saveLocalData(data);
    }
  }

  async getUserData(): Promise<UserData | null> {
    if (!this.userId || !ENV_CONFIG.hasSupabase) {
      return this.getLocalData();
    }

    try {
      const { data, error } = await supabase
        .from('user_data')
        .select('*')
        .eq('user_id', this.userId)
        .single();

      if (error) throw error;
      
      // Cache locally
      this.saveLocalData(data);
      return data;
    } catch (error) {
      console.error('Error fetching user data:', error);
      return this.getLocalData();
    }
  }

  // Backup and Restore
  async createBackup(): Promise<string | null> {
    const profile = await this.getUserProfile();
    const userData = await this.getUserData();
    
    const backup = {
      version: '1.0',
      timestamp: new Date().toISOString(),
      profile,
      data: userData
    };

    if (!this.userId || !ENV_CONFIG.hasSupabase) {
      // Save to localStorage as backup
      localStorage.setItem('auramind_backup', JSON.stringify(backup));
      return 'local_backup';
    }

    try {
      const { data, error } = await supabase
        .from('user_backups')
        .insert({
          user_id: this.userId,
          backup_data: backup,
          created_at: new Date().toISOString()
        })
        .select()
        .single();

      if (error) throw error;
      return data.id;
    } catch (error) {
      console.error('Error creating backup:', error);
      return null;
    }
  }

  async restoreFromBackup(backupId: string): Promise<boolean> {
    if (!this.userId || !ENV_CONFIG.hasSupabase) {
      const backup = localStorage.getItem('auramind_backup');
      if (!backup) return false;
      
      try {
        const backupData = JSON.parse(backup);
        await this.updateUserProfile(backupData.profile);
        await this.syncUserData(backupData.data);
        return true;
      } catch (error) {
        console.error('Error restoring from local backup:', error);
        return false;
      }
    }

    try {
      const { data, error } = await supabase
        .from('user_backups')
        .select('backup_data')
        .eq('id', backupId)
        .eq('user_id', this.userId)
        .single();

      if (error) throw error;
      
      const backup = data.backup_data;
      await this.updateUserProfile(backup.profile);
      await this.syncUserData(backup.data);
      return true;
    } catch (error) {
      console.error('Error restoring backup:', error);
      return false;
    }
  }

  async listBackups(): Promise<Array<{id: string, created_at: string}>> {
    if (!this.userId || !ENV_CONFIG.hasSupabase) {
      const backup = localStorage.getItem('auramind_backup');
      return backup ? [{id: 'local_backup', created_at: new Date().toISOString()}] : [];
    }

    try {
      const { data, error } = await supabase
        .from('user_backups')
        .select('id, created_at')
        .eq('user_id', this.userId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error listing backups:', error);
      return [];
    }
  }

  // Real-time Synchronization
  setupRealtimeSync() {
    if (!this.userId || !ENV_CONFIG.hasSupabase) return null;

    return supabase
      .channel('user_data_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'user_data',
          filter: `user_id=eq.${this.userId}`
        },
        (payload) => {
          console.log('Real-time data change:', payload);
          // Trigger app state update
          window.dispatchEvent(new CustomEvent('auramind_data_sync', { 
            detail: payload 
          }));
        }
      )
      .subscribe();
  }

  // Fallback localStorage methods
  private getLocalProfile(): UserProfile | null {
    try {
      const profile = localStorage.getItem('auramind_profile');
      return profile ? JSON.parse(profile) : null;
    } catch {
      return null;
    }
  }

  private updateLocalProfile(profile: Partial<UserProfile>): boolean {
    try {
      const existing = this.getLocalProfile();
      const updated = { ...existing, ...profile };
      localStorage.setItem('auramind_profile', JSON.stringify(updated));
      return true;
    } catch {
      return false;
    }
  }

  private getLocalData(): UserData | null {
    try {
      const data = localStorage.getItem('auramind_data');
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  }

  private saveLocalData(data: Partial<UserData>): boolean {
    try {
      const existing = this.getLocalData();
      const updated = { ...existing, ...data };
      localStorage.setItem('auramind_data', JSON.stringify(updated));
      return true;
    } catch {
      return false;
    }
  }
}

export const dbService = new DatabaseService();
