
export interface UserActivityData {
  timestamp: Date;
  action: string;
  category: 'task' | 'calendar' | 'communication' | 'system' | 'break';
  duration: number; // in minutes
  context: {
    timeOfDay: 'morning' | 'afternoon' | 'evening' | 'night';
    dayOfWeek: string;
    deviceType: 'mobile' | 'desktop' | 'tablet';
    energyLevel: 'high' | 'medium' | 'low';
    focusScore: number; // 1-10
  };
  outcome: 'completed' | 'abandoned' | 'postponed' | 'delegated';
  productivity: number; // 1-10 rating
}

export interface ProductivityMetrics {
  overall: {
    score: number; // 0-100
    trend: 'improving' | 'stable' | 'declining';
    weeklyAverage: number;
    monthlyAverage: number;
  };
  timeManagement: {
    tasksCompleted: number;
    tasksPlanned: number;
    completionRate: number;
    averageTaskDuration: number;
    timeBlockingEffectiveness: number;
  };
  focusMetrics: {
    deepWorkSessions: number;
    averageFocusSession: number;
    distractionEvents: number;
    flowStateFrequency: number;
  };
  energyPatterns: {
    peakHours: number[];
    lowEnergyPeriods: number[];
    energyVariance: number;
    recoveryTime: number;
  };
}

export interface BehaviorPattern {
  id: string;
  pattern: string;
  frequency: number;
  confidence: number;
  context: Record<string, any>;
  predictiveValue: number;
  lastSeen: Date;
  trend: 'increasing' | 'stable' | 'decreasing';
}

export interface PredictiveInsight {
  type: 'schedule_optimization' | 'energy_management' | 'task_prioritization' | 'break_suggestion';
  confidence: number;
  recommendation: string;
  expectedImpact: number;
  timeframe: string;
  data: Record<string, any>;
}

export interface PerformanceTrend {
  metric: string;
  timeframe: 'daily' | 'weekly' | 'monthly';
  values: Array<{ date: Date; value: number }>;
  trend: 'up' | 'down' | 'stable';
  changeRate: number;
  projectedValue: number;
  insights: string[];
}

class AnalyticsEngine {
  private activityData: UserActivityData[] = [];
  private behaviorPatterns: Map<string, BehaviorPattern> = new Map();
  private learningModels: Map<string, any> = new Map();
  private insights: PredictiveInsight[] = [];

  constructor() {
    this.loadStoredData();
    this.initializeLearningModels();
    this.startAnalyticsCollection();
  }

  // Data Collection
  public recordActivity(activity: Partial<UserActivityData>): void {
    const activityRecord: UserActivityData = {
      timestamp: new Date(),
      action: activity.action || 'unknown',
      category: activity.category || 'system',
      duration: activity.duration || 0,
      context: {
        timeOfDay: this.getTimeOfDay(),
        dayOfWeek: new Date().toLocaleDateString('en-US', { weekday: 'long' }),
        deviceType: this.detectDevice(),
        energyLevel: activity.context?.energyLevel || 'medium',
        focusScore: activity.context?.focusScore || 5
      },
      outcome: activity.outcome || 'completed',
      productivity: activity.productivity || 5
    };

    this.activityData.push(activityRecord);
    this.trimActivityData();
    this.updateBehaviorPatterns(activityRecord);
    this.saveData();
  }

  // User Behavior Pattern Analysis
  public analyzeBehaviorPatterns(): BehaviorPattern[] {
    const patterns: BehaviorPattern[] = [];
    
    // Analyze time-based patterns
    patterns.push(...this.analyzeTimePatterns());
    
    // Analyze task completion patterns
    patterns.push(...this.analyzeTaskPatterns());
    
    // Analyze productivity patterns
    patterns.push(...this.analyzeProductivityPatterns());
    
    // Analyze energy patterns
    patterns.push(...this.analyzeEnergyPatterns());
    
    // Update stored patterns
    patterns.forEach(pattern => {
      this.behaviorPatterns.set(pattern.id, pattern);
    });
    
    return patterns;
  }

  private analyzeTimePatterns(): BehaviorPattern[] {
    const patterns: BehaviorPattern[] = [];
    const timeData = this.groupActivitiesByTime();
    
    // Peak productivity hours
    const peakHours = this.findPeakProductivityHours(timeData);
    if (peakHours.length > 0) {
      patterns.push({
        id: 'peak_productivity_hours',
        pattern: `Most productive during ${peakHours.join(', ')}`,
        frequency: this.calculatePatternFrequency('peak_hours', peakHours),
        confidence: 0.8,
        context: { hours: peakHours },
        predictiveValue: 0.9,
        lastSeen: new Date(),
        trend: this.calculateTrend('peak_hours')
      });
    }
    
    // Deep work preferences
    const deepWorkPattern = this.analyzeDeepWorkTimes();
    if (deepWorkPattern) {
      patterns.push(deepWorkPattern);
    }
    
    return patterns;
  }

  private analyzeTaskPatterns(): BehaviorPattern[] {
    const patterns: BehaviorPattern[] = [];
    
    // Task completion velocity
    const completionVelocity = this.analyzeTaskCompletionVelocity();
    patterns.push({
      id: 'task_completion_velocity',
      pattern: `Completes ${completionVelocity.averagePerDay} tasks per day`,
      frequency: completionVelocity.consistency,
      confidence: 0.7,
      context: completionVelocity,
      predictiveValue: 0.8,
      lastSeen: new Date(),
      trend: completionVelocity.trend
    });
    
    // Procrastination patterns
    const procrastinationPattern = this.analyzeProcrastinationPatterns();
    if (procrastinationPattern) {
      patterns.push(procrastinationPattern);
    }
    
    return patterns;
  }

  private analyzeProductivityPatterns(): BehaviorPattern[] {
    const patterns: BehaviorPattern[] = [];
    
    // Productivity cycles
    const productivityCycle = this.analyzeProductivityCycles();
    patterns.push({
      id: 'productivity_cycle',
      pattern: `${productivityCycle.cycleLength}-day productivity cycle`,
      frequency: productivityCycle.regularity,
      confidence: productivityCycle.confidence,
      context: productivityCycle,
      predictiveValue: 0.85,
      lastSeen: new Date(),
      trend: 'stable'
    });
    
    return patterns;
  }

  private analyzeEnergyPatterns(): BehaviorPattern[] {
    const patterns: BehaviorPattern[] = [];
    
    // Energy fluctuation patterns
    const energyPattern = this.analyzeEnergyFluctuations();
    patterns.push({
      id: 'energy_fluctuation',
      pattern: `Energy peaks at ${energyPattern.peakTimes.join(', ')}, dips at ${energyPattern.lowTimes.join(', ')}`,
      frequency: energyPattern.consistency,
      confidence: 0.75,
      context: energyPattern,
      predictiveValue: 0.8,
      lastSeen: new Date(),
      trend: energyPattern.trend
    });
    
    return patterns;
  }

  // Productivity Metrics Calculation
  public calculateProductivityMetrics(timeframe: 'week' | 'month' | 'quarter' = 'week'): ProductivityMetrics {
    const relevantData = this.getDataForTimeframe(timeframe);
    
    return {
      overall: this.calculateOverallMetrics(relevantData),
      timeManagement: this.calculateTimeManagementMetrics(relevantData),
      focusMetrics: this.calculateFocusMetrics(relevantData),
      energyPatterns: this.calculateEnergyMetrics(relevantData)
    };
  }

  private calculateOverallMetrics(data: UserActivityData[]): ProductivityMetrics['overall'] {
    const scores = data.map(d => d.productivity);
    const average = scores.reduce((sum, score) => sum + score, 0) / scores.length || 0;
    
    const weeklyData = this.getDataForTimeframe('week');
    const monthlyData = this.getDataForTimeframe('month');
    
    const weeklyAverage = weeklyData.map(d => d.productivity).reduce((sum, score) => sum + score, 0) / weeklyData.length || 0;
    const monthlyAverage = monthlyData.map(d => d.productivity).reduce((sum, score) => sum + score, 0) / monthlyData.length || 0;
    
    return {
      score: (average / 10) * 100,
      trend: this.calculateProductivityTrend(data),
      weeklyAverage: (weeklyAverage / 10) * 100,
      monthlyAverage: (monthlyAverage / 10) * 100
    };
  }

  private calculateTimeManagementMetrics(data: UserActivityData[]): ProductivityMetrics['timeManagement'] {
    const taskData = data.filter(d => d.category === 'task');
    const completed = taskData.filter(d => d.outcome === 'completed').length;
    const total = taskData.length;
    
    return {
      tasksCompleted: completed,
      tasksPlanned: total,
      completionRate: total > 0 ? (completed / total) * 100 : 0,
      averageTaskDuration: taskData.reduce((sum, task) => sum + task.duration, 0) / taskData.length || 0,
      timeBlockingEffectiveness: this.calculateTimeBlockingEffectiveness(taskData)
    };
  }

  private calculateFocusMetrics(data: UserActivityData[]): ProductivityMetrics['focusMetrics'] {
    const focusData = data.filter(d => d.context.focusScore >= 7);
    const deepWorkSessions = focusData.filter(d => d.duration >= 30).length;
    
    return {
      deepWorkSessions,
      averageFocusSession: focusData.reduce((sum, session) => sum + session.duration, 0) / focusData.length || 0,
      distractionEvents: data.filter(d => d.context.focusScore <= 3).length,
      flowStateFrequency: this.calculateFlowStateFrequency(data)
    };
  }

  private calculateEnergyMetrics(data: UserActivityData[]): ProductivityMetrics['energyPatterns'] {
    const energyData = this.groupDataByHour(data);
    const peakHours = this.findEnergyPeaks(energyData);
    const lowHours = this.findEnergyLows(energyData);
    
    return {
      peakHours,
      lowEnergyPeriods: lowHours,
      energyVariance: this.calculateEnergyVariance(data),
      recoveryTime: this.calculateRecoveryTime(data)
    };
  }

  // Predictive Scheduling Algorithms
  public generatePredictiveSchedule(tasks: any[], timeframe: 'day' | 'week' = 'day'): any[] {
    const patterns = this.analyzeBehaviorPatterns();
    const metrics = this.calculateProductivityMetrics();
    
    const optimizedSchedule = this.optimizeTaskScheduling(tasks, patterns, metrics);
    
    return this.applyPredictiveInsights(optimizedSchedule, patterns);
  }

  private optimizeTaskScheduling(tasks: any[], patterns: BehaviorPattern[], metrics: ProductivityMetrics): any[] {
    const schedule = [];
    const peakHoursPattern = patterns.find(p => p.id === 'peak_productivity_hours');
    const peakHours = peakHoursPattern?.context.hours || [9, 10, 11, 14, 15];
    
    // Sort tasks by priority and energy requirements
    const sortedTasks = tasks.sort((a, b) => {
      if (a.priority !== b.priority) {
        const priorityOrder = { high: 3, medium: 2, low: 1 };
        return priorityOrder[b.priority] - priorityOrder[a.priority];
      }
      return b.estimatedEffort - a.estimatedEffort;
    });
    
    // Schedule high-energy tasks during peak hours
    for (const task of sortedTasks) {
      const optimalTime = this.findOptimalTimeSlot(task, peakHours, metrics);
      schedule.push({
        ...task,
        scheduledTime: optimalTime,
        predictedDuration: this.predictTaskDuration(task, patterns),
        confidence: this.calculateSchedulingConfidence(task, optimalTime, patterns)
      });
    }
    
    return schedule;
  }

  private applyPredictiveInsights(schedule: any[], patterns: BehaviorPattern[]): any[] {
    return schedule.map(item => {
      const insights = this.generateTaskInsights(item, patterns);
      return {
        ...item,
        insights,
        adjustments: this.suggestScheduleAdjustments(item, patterns)
      };
    });
  }

  // Performance Trend Analysis
  public analyzePerformanceTrends(timeframe: 'week' | 'month' | 'quarter' = 'month'): PerformanceTrend[] {
    const trends: PerformanceTrend[] = [];
    
    // Productivity trend
    trends.push(this.analyzeProductivityTrend(timeframe));
    
    // Focus trend
    trends.push(this.analyzeFocusTrend(timeframe));
    
    // Task completion trend
    trends.push(this.analyzeTaskCompletionTrend(timeframe));
    
    // Energy level trend
    trends.push(this.analyzeEnergyTrend(timeframe));
    
    return trends;
  }

  private analyzeProductivityTrend(timeframe: string): PerformanceTrend {
    const data = this.getDataForTimeframe(timeframe);
    const dailyProductivity = this.groupDataByDay(data);
    
    const values = dailyProductivity.map(day => ({
      date: day.date,
      value: day.averageProductivity
    }));
    
    const trend = this.calculateTrendDirection(values.map(v => v.value));
    const changeRate = this.calculateChangeRate(values);
    
    return {
      metric: 'Overall Productivity',
      timeframe: timeframe as any,
      values,
      trend,
      changeRate,
      projectedValue: this.projectFutureValue(values, 7), // 7 days ahead
      insights: this.generateTrendInsights('productivity', trend, changeRate)
    };
  }

  private analyzeFocusTrend(timeframe: string): PerformanceTrend {
    const data = this.getDataForTimeframe(timeframe);
    const dailyFocus = this.groupDataByDay(data, 'focusScore');
    
    const values = dailyFocus.map(day => ({
      date: day.date,
      value: day.averageFocus
    }));
    
    const trend = this.calculateTrendDirection(values.map(v => v.value));
    const changeRate = this.calculateChangeRate(values);
    
    return {
      metric: 'Focus Quality',
      timeframe: timeframe as any,
      values,
      trend,
      changeRate,
      projectedValue: this.projectFutureValue(values, 7),
      insights: this.generateTrendInsights('focus', trend, changeRate)
    };
  }

  // Insight Generation
  public generatePredictiveInsights(): PredictiveInsight[] {
    const patterns = this.analyzeBehaviorPatterns();
    const metrics = this.calculateProductivityMetrics();
    const trends = this.analyzePerformanceTrends();
    
    const insights: PredictiveInsight[] = [];
    
    // Schedule optimization insights
    insights.push(...this.generateScheduleOptimizationInsights(patterns, metrics));
    
    // Energy management insights
    insights.push(...this.generateEnergyManagementInsights(patterns, metrics));
    
    // Task prioritization insights
    insights.push(...this.generateTaskPrioritizationInsights(patterns, trends));
    
    // Break suggestion insights
    insights.push(...this.generateBreakSuggestionInsights(patterns, metrics));
    
    this.insights = insights;
    return insights;
  }

  private generateScheduleOptimizationInsights(patterns: BehaviorPattern[], metrics: ProductivityMetrics): PredictiveInsight[] {
    const insights: PredictiveInsight[] = [];
    
    const peakPattern = patterns.find(p => p.id === 'peak_productivity_hours');
    if (peakPattern && peakPattern.confidence > 0.7) {
      insights.push({
        type: 'schedule_optimization',
        confidence: peakPattern.confidence,
        recommendation: `Schedule your most important tasks during ${peakPattern.context.hours.join(', ')} when you're most productive`,
        expectedImpact: 0.25, // 25% productivity increase
        timeframe: 'daily',
        data: { peakHours: peakPattern.context.hours }
      });
    }
    
    if (metrics.timeManagement.completionRate < 70) {
      insights.push({
        type: 'schedule_optimization',
        confidence: 0.8,
        recommendation: 'Consider reducing your daily task load by 20% to improve completion rates',
        expectedImpact: 0.15,
        timeframe: 'weekly',
        data: { currentCompletionRate: metrics.timeManagement.completionRate }
      });
    }
    
    return insights;
  }

  private generateEnergyManagementInsights(patterns: BehaviorPattern[], metrics: ProductivityMetrics): PredictiveInsight[] {
    const insights: PredictiveInsight[] = [];
    
    const energyPattern = patterns.find(p => p.id === 'energy_fluctuation');
    if (energyPattern && energyPattern.confidence > 0.6) {
      insights.push({
        type: 'energy_management',
        confidence: energyPattern.confidence,
        recommendation: `Take breaks during low energy periods: ${energyPattern.context.lowTimes.join(', ')}`,
        expectedImpact: 0.2,
        timeframe: 'daily',
        data: energyPattern.context
      });
    }
    
    if (metrics.energyPatterns.energyVariance > 2.5) {
      insights.push({
        type: 'energy_management',
        confidence: 0.75,
        recommendation: 'Your energy levels vary significantly. Consider establishing a more consistent sleep and exercise routine',
        expectedImpact: 0.3,
        timeframe: 'weekly',
        data: { variance: metrics.energyPatterns.energyVariance }
      });
    }
    
    return insights;
  }

  // Utility Methods
  private getTimeOfDay(): 'morning' | 'afternoon' | 'evening' | 'night' {
    const hour = new Date().getHours();
    if (hour < 6) return 'night';
    if (hour < 12) return 'morning';
    if (hour < 18) return 'afternoon';
    if (hour < 22) return 'evening';
    return 'night';
  }

  private detectDevice(): 'mobile' | 'desktop' | 'tablet' {
    const userAgent = navigator.userAgent;
    if (/tablet|ipad|playbook|silk/i.test(userAgent)) return 'tablet';
    if (/mobile|iphone|ipod|android|blackberry|opera|mini|windows\sce|palm|smartphone|iemobile/i.test(userAgent)) return 'mobile';
    return 'desktop';
  }

  private trimActivityData(): void {
    // Keep only last 10,000 entries
    if (this.activityData.length > 10000) {
      this.activityData = this.activityData.slice(-10000);
    }
  }

  private saveData(): void {
    try {
      localStorage.setItem('auramind_analytics', JSON.stringify({
        activityData: this.activityData.slice(-1000), // Save last 1000 entries
        behaviorPatterns: Array.from(this.behaviorPatterns.entries()),
        insights: this.insights
      }));
    } catch (error) {
      console.error('Failed to save analytics data:', error);
    }
  }

  private loadStoredData(): void {
    try {
      const stored = localStorage.getItem('auramind_analytics');
      if (stored) {
        const data = JSON.parse(stored);
        this.activityData = data.activityData || [];
        this.behaviorPatterns = new Map(data.behaviorPatterns || []);
        this.insights = data.insights || [];
      }
    } catch (error) {
      console.error('Failed to load analytics data:', error);
    }
  }

  // Placeholder methods for complex calculations
  private updateBehaviorPatterns(activity: UserActivityData): void {
    // Implementation for real-time pattern updates
  }

  private initializeLearningModels(): void {
    // Initialize machine learning models for predictions
  }

  private startAnalyticsCollection(): void {
    // Start background data collection
  }

  private groupActivitiesByTime(): any {
    // Group activities by time periods
    return {};
  }

  private findPeakProductivityHours(timeData: any): number[] {
    // Find hours with highest productivity
    return [9, 10, 11, 14, 15];
  }

  private calculatePatternFrequency(pattern: string, data: any): number {
    // Calculate how often a pattern occurs
    return 0.8;
  }

  private calculateTrend(pattern: string): 'increasing' | 'stable' | 'decreasing' {
    // Calculate if pattern is increasing, stable, or decreasing
    return 'stable';
  }

  private analyzeDeepWorkTimes(): BehaviorPattern | null {
    // Analyze when user does deep work best
    return null;
  }

  private analyzeTaskCompletionVelocity(): any {
    return {
      averagePerDay: 5,
      consistency: 0.7,
      trend: 'stable' as const
    };
  }

  private analyzeProcrastinationPatterns(): BehaviorPattern | null {
    return null;
  }

  private analyzeProductivityCycles(): any {
    return {
      cycleLength: 7,
      regularity: 0.6,
      confidence: 0.7
    };
  }

  private analyzeEnergyFluctuations(): any {
    return {
      peakTimes: ['9:00', '14:00'],
      lowTimes: ['13:00', '16:00'],
      consistency: 0.8,
      trend: 'stable' as const
    };
  }

  private getDataForTimeframe(timeframe: string): UserActivityData[] {
    const now = new Date();
    let cutoffDate = new Date();
    
    switch (timeframe) {
      case 'week':
        cutoffDate.setDate(now.getDate() - 7);
        break;
      case 'month':
        cutoffDate.setMonth(now.getMonth() - 1);
        break;
      case 'quarter':
        cutoffDate.setMonth(now.getMonth() - 3);
        break;
    }
    
    return this.activityData.filter(activity => activity.timestamp >= cutoffDate);
  }

  private calculateProductivityTrend(data: UserActivityData[]): 'improving' | 'stable' | 'declining' {
    if (data.length < 2) return 'stable';
    
    const recent = data.slice(-7).reduce((sum, d) => sum + d.productivity, 0) / 7;
    const previous = data.slice(-14, -7).reduce((sum, d) => sum + d.productivity, 0) / 7;
    
    if (recent > previous + 0.5) return 'improving';
    if (recent < previous - 0.5) return 'declining';
    return 'stable';
  }

  private calculateTimeBlockingEffectiveness(taskData: UserActivityData[]): number {
    // Calculate how effective time blocking is
    return 75;
  }

  private calculateFlowStateFrequency(data: UserActivityData[]): number {
    // Calculate frequency of flow states
    return data.filter(d => d.context.focusScore >= 8 && d.duration >= 45).length;
  }

  private groupDataByHour(data: UserActivityData[]): any {
    return {};
  }

  private findEnergyPeaks(energyData: any): number[] {
    return [9, 14];
  }

  private findEnergyLows(energyData: any): number[] {
    return [13, 16];
  }

  private calculateEnergyVariance(data: UserActivityData[]): number {
    return 2.1;
  }

  private calculateRecoveryTime(data: UserActivityData[]): number {
    return 15; // minutes
  }

  private findOptimalTimeSlot(task: any, peakHours: number[], metrics: ProductivityMetrics): Date {
    // Find optimal time slot for task
    const now = new Date();
    const optimalHour = peakHours[0] || 9;
    now.setHours(optimalHour, 0, 0, 0);
    return now;
  }

  private predictTaskDuration(task: any, patterns: BehaviorPattern[]): number {
    // Predict how long task will actually take
    return task.estimatedDuration * 1.2; // 20% buffer
  }

  private calculateSchedulingConfidence(task: any, time: Date, patterns: BehaviorPattern[]): number {
    return 0.8;
  }

  private generateTaskInsights(task: any, patterns: BehaviorPattern[]): string[] {
    return ['Consider breaking this task into smaller chunks'];
  }

  private suggestScheduleAdjustments(task: any, patterns: BehaviorPattern[]): string[] {
    return ['Move to peak productivity hours for better results'];
  }

  private analyzeTaskCompletionTrend(timeframe: string): PerformanceTrend {
    const data = this.getDataForTimeframe(timeframe);
    const taskData = data.filter(d => d.category === 'task');
    const dailyCompletion = this.groupDataByDay(taskData, 'completion');
    
    const values = dailyCompletion.map(day => ({
      date: day.date,
      value: day.completionRate
    }));
    
    return {
      metric: 'Task Completion Rate',
      timeframe: timeframe as any,
      values,
      trend: this.calculateTrendDirection(values.map(v => v.value)),
      changeRate: this.calculateChangeRate(values),
      projectedValue: this.projectFutureValue(values, 7),
      insights: []
    };
  }

  private analyzeEnergyTrend(timeframe: string): PerformanceTrend {
    const data = this.getDataForTimeframe(timeframe);
    const dailyEnergy = this.groupDataByDay(data, 'energy');
    
    const values = dailyEnergy.map(day => ({
      date: day.date,
      value: day.averageEnergy
    }));
    
    return {
      metric: 'Energy Levels',
      timeframe: timeframe as any,
      values,
      trend: this.calculateTrendDirection(values.map(v => v.value)),
      changeRate: this.calculateChangeRate(values),
      projectedValue: this.projectFutureValue(values, 7),
      insights: []
    };
  }

  private groupDataByDay(data: UserActivityData[], metric?: string): any[] {
    // Group data by day and calculate averages
    return [];
  }

  private calculateTrendDirection(values: number[]): 'up' | 'down' | 'stable' {
    if (values.length < 2) return 'stable';
    
    const first = values.slice(0, Math.floor(values.length / 2)).reduce((sum, v) => sum + v, 0) / Math.floor(values.length / 2);
    const second = values.slice(Math.floor(values.length / 2)).reduce((sum, v) => sum + v, 0) / (values.length - Math.floor(values.length / 2));
    
    if (second > first + 0.1) return 'up';
    if (second < first - 0.1) return 'down';
    return 'stable';
  }

  private calculateChangeRate(values: Array<{ date: Date; value: number }>): number {
    if (values.length < 2) return 0;
    
    const first = values[0].value;
    const last = values[values.length - 1].value;
    
    return ((last - first) / first) * 100;
  }

  private projectFutureValue(values: Array<{ date: Date; value: number }>, daysAhead: number): number {
    if (values.length < 2) return values[0]?.value || 0;
    
    // Simple linear projection
    const trend = this.calculateChangeRate(values) / values.length;
    const lastValue = values[values.length - 1].value;
    
    return lastValue + (trend * daysAhead);
  }

  private generateTrendInsights(metric: string, trend: 'up' | 'down' | 'stable', changeRate: number): string[] {
    const insights: string[] = [];
    
    if (trend === 'up' && changeRate > 10) {
      insights.push(`${metric} is improving significantly (+${changeRate.toFixed(1)}%)`);
    } else if (trend === 'down' && changeRate < -10) {
      insights.push(`${metric} is declining and needs attention (${changeRate.toFixed(1)}%)`);
    } else if (trend === 'stable') {
      insights.push(`${metric} is stable with consistent performance`);
    }
    
    return insights;
  }

  private generateTaskPrioritizationInsights(patterns: BehaviorPattern[], trends: PerformanceTrend[]): PredictiveInsight[] {
    return [{
      type: 'task_prioritization',
      confidence: 0.8,
      recommendation: 'Prioritize high-energy tasks during your peak hours for optimal results',
      expectedImpact: 0.2,
      timeframe: 'daily',
      data: {}
    }];
  }

  private generateBreakSuggestionInsights(patterns: BehaviorPattern[], metrics: ProductivityMetrics): PredictiveInsight[] {
    return [{
      type: 'break_suggestion',
      confidence: 0.75,
      recommendation: 'Take a 15-minute break every 90 minutes to maintain focus',
      expectedImpact: 0.15,
      timeframe: 'daily',
      data: { currentFocusScore: metrics.focusMetrics.averageFocusSession }
    }];
  }

  // Public API Methods
  public getProductivityScore(): number {
    const metrics = this.calculateProductivityMetrics();
    return metrics.overall.score;
  }

  public getBehaviorInsights(): string[] {
    const patterns = this.analyzeBehaviorPatterns();
    return patterns.map(p => p.pattern);
  }

  public getPredictiveRecommendations(): string[] {
    const insights = this.generatePredictiveInsights();
    return insights.map(i => i.recommendation);
  }

  public exportAnalyticsData(): any {
    return {
      activityData: this.activityData,
      behaviorPatterns: Array.from(this.behaviorPatterns.entries()),
      insights: this.insights,
      metrics: this.calculateProductivityMetrics(),
      trends: this.analyzePerformanceTrends()
    };
  }
}

export const analyticsEngine = new AnalyticsEngine();
