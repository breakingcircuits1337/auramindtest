
interface CacheItem<T> {
  data: T;
  timestamp: number;
  ttl: number;
  accessed: number;
  hits: number;
}

interface CacheStats {
  hits: number;
  misses: number;
  size: number;
  hitRate: number;
}

interface CacheConfig {
  maxSize: number;
  defaultTTL: number;
  checkInterval: number;
  enableStats: boolean;
}

class CacheService {
  private cache: Map<string, CacheItem<any>> = new Map();
  private stats: CacheStats = { hits: 0, misses: 0, size: 0, hitRate: 0 };
  private config: CacheConfig;
  private cleanupInterval: NodeJS.Timeout | null = null;

  constructor(config: Partial<CacheConfig> = {}) {
    this.config = {
      maxSize: config.maxSize || 1000,
      defaultTTL: config.defaultTTL || 3600000, // 1 hour
      checkInterval: config.checkInterval || 300000, // 5 minutes
      enableStats: config.enableStats !== false
    };

    this.startCleanup();
  }

  // Core Cache Operations
  public set<T>(key: string, data: T, ttl?: number): void {
    const item: CacheItem<T> = {
      data,
      timestamp: Date.now(),
      ttl: ttl || this.config.defaultTTL,
      accessed: Date.now(),
      hits: 0
    };

    // Remove oldest items if cache is full
    if (this.cache.size >= this.config.maxSize) {
      this.evictLRU();
    }

    this.cache.set(key, item);
    this.updateStats();
  }

  public get<T>(key: string): T | null {
    const item = this.cache.get(key);
    
    if (!item) {
      if (this.config.enableStats) {
        this.stats.misses++;
      }
      return null;
    }

    // Check if expired
    if (this.isExpired(item)) {
      this.cache.delete(key);
      if (this.config.enableStats) {
        this.stats.misses++;
      }
      return null;
    }

    // Update access tracking
    item.accessed = Date.now();
    item.hits++;

    if (this.config.enableStats) {
      this.stats.hits++;
    }

    return item.data;
  }

  public has(key: string): boolean {
    const item = this.cache.get(key);
    return item !== undefined && !this.isExpired(item);
  }

  public delete(key: string): boolean {
    const result = this.cache.delete(key);
    this.updateStats();
    return result;
  }

  public clear(): void {
    this.cache.clear();
    this.resetStats();
  }

  // Advanced Cache Operations
  public getOrSet<T>(
    key: string, 
    factory: () => Promise<T> | T, 
    ttl?: number
  ): Promise<T> {
    const cached = this.get<T>(key);
    
    if (cached !== null) {
      return Promise.resolve(cached);
    }

    const result = factory();
    
    if (result instanceof Promise) {
      return result.then(data => {
        this.set(key, data, ttl);
        return data;
      });
    } else {
      this.set(key, result, ttl);
      return Promise.resolve(result);
    }
  }

  public mget(keys: string[]): Record<string, any> {
    const result: Record<string, any> = {};
    
    for (const key of keys) {
      const value = this.get(key);
      if (value !== null) {
        result[key] = value;
      }
    }
    
    return result;
  }

  public mset(items: Record<string, any>, ttl?: number): void {
    for (const [key, value] of Object.entries(items)) {
      this.set(key, value, ttl);
    }
  }

  public keys(pattern?: RegExp): string[] {
    const allKeys = Array.from(this.cache.keys());
    
    if (!pattern) {
      return allKeys;
    }
    
    return allKeys.filter(key => pattern.test(key));
  }

  public values(): any[] {
    return Array.from(this.cache.values())
      .filter(item => !this.isExpired(item))
      .map(item => item.data);
  }

  // Cache Management
  private startCleanup(): void {
    this.cleanupInterval = setInterval(() => {
      this.cleanup();
    }, this.config.checkInterval);
  }

  private cleanup(): void {
    const now = Date.now();
    const toDelete: string[] = [];

    for (const [key, item] of this.cache.entries()) {
      if (this.isExpired(item)) {
        toDelete.push(key);
      }
    }

    for (const key of toDelete) {
      this.cache.delete(key);
    }

    this.updateStats();
  }

  private evictLRU(): void {
    let oldestKey: string | null = null;
    let oldestAccess = Date.now();

    for (const [key, item] of this.cache.entries()) {
      if (item.accessed < oldestAccess) {
        oldestAccess = item.accessed;
        oldestKey = key;
      }
    }

    if (oldestKey) {
      this.cache.delete(oldestKey);
    }
  }

  private isExpired(item: CacheItem<any>): boolean {
    return Date.now() - item.timestamp > item.ttl;
  }

  private updateStats(): void {
    if (!this.config.enableStats) return;

    this.stats.size = this.cache.size;
    const total = this.stats.hits + this.stats.misses;
    this.stats.hitRate = total > 0 ? (this.stats.hits / total) * 100 : 0;
  }

  private resetStats(): void {
    this.stats = { hits: 0, misses: 0, size: 0, hitRate: 0 };
  }

  // Public API
  public getStats(): CacheStats {
    return { ...this.stats };
  }

  public getConfig(): CacheConfig {
    return { ...this.config };
  }

  public destroy(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
    }
    this.clear();
  }
}

// Specialized cache instances
export const memoryCache = new CacheService({
  maxSize: 1000,
  defaultTTL: 3600000, // 1 hour
  enableStats: true
});

export const apiCache = new CacheService({
  maxSize: 500,
  defaultTTL: 300000, // 5 minutes
  enableStats: true
});

export const userCache = new CacheService({
  maxSize: 100,
  defaultTTL: 1800000, // 30 minutes
  enableStats: true
});

// Browser storage cache with persistence
class PersistentCache extends CacheService {
  private storageKey: string;

  constructor(storageKey: string, config: Partial<CacheConfig> = {}) {
    super(config);
    this.storageKey = storageKey;
    this.loadFromStorage();
  }

  public set<T>(key: string, data: T, ttl?: number): void {
    super.set(key, data, ttl);
    this.saveToStorage();
  }

  public delete(key: string): boolean {
    const result = super.delete(key);
    this.saveToStorage();
    return result;
  }

  public clear(): void {
    super.clear();
    this.saveToStorage();
  }

  private loadFromStorage(): void {
    try {
      const stored = localStorage.getItem(this.storageKey);
      if (stored) {
        const data = JSON.parse(stored);
        for (const [key, item] of Object.entries(data)) {
          if (!this.isExpired(item as CacheItem<any>)) {
            this.cache.set(key, item as CacheItem<any>);
          }
        }
      }
    } catch (error) {
      console.warn('Failed to load cache from storage:', error);
    }
  }

  private saveToStorage(): void {
    try {
      const data = Object.fromEntries(this.cache.entries());
      localStorage.setItem(this.storageKey, JSON.stringify(data));
    } catch (error) {
      console.warn('Failed to save cache to storage:', error);
    }
  }

  private isExpired(item: CacheItem<any>): boolean {
    return Date.now() - item.timestamp > item.ttl;
  }
}

export const persistentCache = new PersistentCache('auramind_cache', {
  maxSize: 200,
  defaultTTL: 86400000, // 24 hours
});
