
import { calendarManager } from './calendar';
import { taskManager } from './taskManager';

export interface UserContext {
  temporal: {
    currentTime: Date;
    timeOfDay: 'morning' | 'afternoon' | 'evening' | 'night';
    dayOfWeek: string;
    isWorkingHours: boolean;
    upcomingEvents: any[];
    recentTasks: any[];
  };
  behavioral: {
    productivity: number; // 0-100
    mood: 'focused' | 'relaxed' | 'stressed' | 'productive';
    energy: 'low' | 'medium' | 'high';
    recentActions: string[];
    preferences: Record<string, any>;
  };
  environmental: {
    device: 'mobile' | 'desktop' | 'tablet';
    location?: string;
    networkQuality: 'poor' | 'good' | 'excellent';
    batteryLevel?: number;
  };
  cognitive: {
    currentFocus?: string;
    distractionLevel: 'low' | 'medium' | 'high';
    multitaskingCapacity: number;
    learningStyle: 'visual' | 'auditory' | 'kinesthetic';
  };
}

class ContextProcessor {
  private context: UserContext;
  private actionHistory: Array<{ action: string; timestamp: Date; success: boolean }> = [];
  private learningPatterns: Map<string, any> = new Map();

  constructor() {
    this.context = this.initializeContext();
    this.startContextMonitoring();
  }

  private initializeContext(): UserContext {
    const now = new Date();
    const hour = now.getHours();
    
    return {
      temporal: {
        currentTime: now,
        timeOfDay: this.getTimeOfDay(hour),
        dayOfWeek: now.toLocaleDateString('en-US', { weekday: 'long' }),
        isWorkingHours: this.isWorkingHours(hour),
        upcomingEvents: [],
        recentTasks: []
      },
      behavioral: {
        productivity: 70,
        mood: 'focused',
        energy: 'medium',
        recentActions: [],
        preferences: this.loadUserPreferences()
      },
      environmental: {
        device: this.detectDevice(),
        networkQuality: 'good',
        batteryLevel: this.getBatteryLevel()
      },
      cognitive: {
        distractionLevel: 'low',
        multitaskingCapacity: 3,
        learningStyle: 'visual'
      }
    };
  }

  private getTimeOfDay(hour: number): 'morning' | 'afternoon' | 'evening' | 'night' {
    if (hour < 6) return 'night';
    if (hour < 12) return 'morning';
    if (hour < 18) return 'afternoon';
    if (hour < 22) return 'evening';
    return 'night';
  }

  private isWorkingHours(hour: number): boolean {
    const workStart = parseInt(localStorage.getItem('workStart') || '9');
    const workEnd = parseInt(localStorage.getItem('workEnd') || '17');
    return hour >= workStart && hour < workEnd;
  }

  private detectDevice(): 'mobile' | 'desktop' | 'tablet' {
    const userAgent = navigator.userAgent;
    if (/tablet|ipad|playbook|silk/i.test(userAgent)) return 'tablet';
    if (/mobile|iphone|ipod|android|blackberry|opera|mini|windows\sce|palm|smartphone|iemobile/i.test(userAgent)) return 'mobile';
    return 'desktop';
  }

  private getBatteryLevel(): number | undefined {
    // Modern browsers may not support battery API
    if ('getBattery' in navigator) {
      (navigator as any).getBattery().then((battery: any) => {
        return Math.round(battery.level * 100);
      });
    }
    return undefined;
  }

  private loadUserPreferences(): Record<string, any> {
    try {
      return JSON.parse(localStorage.getItem('userPreferences') || '{}');
    } catch {
      return {};
    }
  }

  private startContextMonitoring(): void {
    // Update context every minute
    setInterval(() => {
      this.updateContext();
    }, 60000);

    // Monitor user activity
    this.setupActivityMonitoring();
  }

  private setupActivityMonitoring(): void {
    let lastActivity = Date.now();
    let activityScore = 100;

    const updateActivity = () => {
      const now = Date.now();
      const timeSinceLastActivity = now - lastActivity;
      
      if (timeSinceLastActivity < 30000) { // Less than 30 seconds
        activityScore = Math.min(100, activityScore + 2);
      } else {
        activityScore = Math.max(0, activityScore - 1);
      }

      this.context.behavioral.productivity = activityScore;
      lastActivity = now;
    };

    ['click', 'keypress', 'scroll', 'mousemove'].forEach(event => {
      document.addEventListener(event, updateActivity, { passive: true });
    });
  }

  public async updateContext(): Promise<void> {
    const now = new Date();
    
    // Update temporal context
    this.context.temporal.currentTime = now;
    this.context.temporal.timeOfDay = this.getTimeOfDay(now.getHours());
    this.context.temporal.isWorkingHours = this.isWorkingHours(now.getHours());
    
    // Update upcoming events
    try {
      this.context.temporal.upcomingEvents = calendarManager.getUpcomingEvents(24);
    } catch (error) {
      console.error('Failed to update calendar events:', error);
    }

    // Update recent tasks
    try {
      this.context.temporal.recentTasks = taskManager.getRecentTasks(10);
    } catch (error) {
      console.error('Failed to update recent tasks:', error);
    }

    // Analyze patterns and adjust mood/energy
    this.analyzeBehavioralPatterns();
  }

  private analyzeBehavioralPatterns(): void {
    const now = new Date();
    const hour = now.getHours();
    
    // Energy level based on time and activity
    if (this.context.behavioral.productivity > 80) {
      this.context.behavioral.energy = 'high';
      this.context.behavioral.mood = 'productive';
    } else if (this.context.behavioral.productivity > 50) {
      this.context.behavioral.energy = 'medium';
      this.context.behavioral.mood = 'focused';
    } else {
      this.context.behavioral.energy = 'low';
      if (hour < 10 || hour > 20) {
        this.context.behavioral.mood = 'relaxed';
      } else {
        this.context.behavioral.mood = 'stressed';
      }
    }

    // Distraction level based on multitasking
    const recentActionCount = this.actionHistory.filter(
      action => Date.now() - action.timestamp.getTime() < 300000 // Last 5 minutes
    ).length;

    if (recentActionCount > 10) {
      this.context.cognitive.distractionLevel = 'high';
    } else if (recentActionCount > 5) {
      this.context.cognitive.distractionLevel = 'medium';
    } else {
      this.context.cognitive.distractionLevel = 'low';
    }
  }

  public recordAction(action: string, success: boolean = true): void {
    this.actionHistory.push({
      action,
      timestamp: new Date(),
      success
    });

    // Keep only last 100 actions
    if (this.actionHistory.length > 100) {
      this.actionHistory = this.actionHistory.slice(-100);
    }

    // Update recent actions in behavioral context
    this.context.behavioral.recentActions = this.actionHistory
      .slice(-5)
      .map(a => a.action);

    // Learn from patterns
    this.updateLearningPatterns(action, success);
  }

  private updateLearningPatterns(action: string, success: boolean): void {
    const key = `${action}_${this.context.temporal.timeOfDay}_${this.context.behavioral.mood}`;
    const existing = this.learningPatterns.get(key) || { attempts: 0, successes: 0 };
    
    existing.attempts++;
    if (success) existing.successes++;
    
    this.learningPatterns.set(key, existing);
  }

  public getContextualRecommendations(): string[] {
    const recommendations: string[] = [];
    const { temporal, behavioral, cognitive } = this.context;

    // Time-based recommendations
    if (temporal.timeOfDay === 'morning' && behavioral.energy === 'high') {
      recommendations.push('Great time for complex tasks that require deep focus');
    }

    if (temporal.isWorkingHours && temporal.upcomingEvents.length > 3) {
      recommendations.push('You have a busy schedule ahead. Consider time-blocking for important tasks');
    }

    // Energy-based recommendations
    if (behavioral.energy === 'low' && cognitive.distractionLevel === 'high') {
      recommendations.push('Consider taking a short break or doing light administrative tasks');
    }

    // Productivity recommendations
    if (behavioral.productivity < 30) {
      recommendations.push('Try the Pomodoro technique to boost focus');
    }

    // Meeting preparation
    const nextMeeting = temporal.upcomingEvents.find(event => 
      event.start.getTime() - Date.now() < 3600000 // Within 1 hour
    );
    if (nextMeeting) {
      recommendations.push(`Upcoming meeting: "${nextMeeting.title}" in ${Math.round((nextMeeting.start.getTime() - Date.now()) / 60000)} minutes`);
    }

    return recommendations;
  }

  public getEnhancedPromptContext(): string {
    const { temporal, behavioral, cognitive, environmental } = this.context;
    const recommendations = this.getContextualRecommendations();

    return `
    Current Context:
    - Time: ${temporal.currentTime.toLocaleString()} (${temporal.timeOfDay}, ${temporal.dayOfWeek})
    - Working Hours: ${temporal.isWorkingHours ? 'Yes' : 'No'}
    - Energy Level: ${behavioral.energy}
    - Mood: ${behavioral.mood}
    - Productivity Score: ${behavioral.productivity}/100
    - Distraction Level: ${cognitive.distractionLevel}
    - Device: ${environmental.device}
    - Upcoming Events: ${temporal.upcomingEvents.length}
    - Recent Actions: ${behavioral.recentActions.join(', ')}
    
    Smart Recommendations:
    ${recommendations.map(r => `- ${r}`).join('\n')}
    
    Please provide contextually appropriate responses considering the user's current state and schedule.
    `;
  }

  public getContext(): UserContext {
    return { ...this.context };
  }

  public updatePreferences(preferences: Record<string, any>): void {
    this.context.behavioral.preferences = { ...this.context.behavioral.preferences, ...preferences };
    localStorage.setItem('userPreferences', JSON.stringify(this.context.behavioral.preferences));
  }
}

export const contextProcessor = new ContextProcessor();
