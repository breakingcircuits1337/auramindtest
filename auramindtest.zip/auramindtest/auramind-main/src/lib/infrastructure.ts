
import { wsService } from './websocket';
import { monitoringService } from './monitoring';
import { memoryCache, apiCache, userCache, persistentCache } from './cache';
import { apiRateLimitService, clientRateLimiter } from './rateLimiter';
import { dbService } from './database';

interface InfrastructureHealth {
  status: 'healthy' | 'degraded' | 'critical';
  services: Record<string, {
    status: 'up' | 'down' | 'degraded';
    lastCheck: Date;
    responseTime?: number;
    errorRate?: number;
  }>;
  metrics: {
    cacheHitRate: number;
    averageResponseTime: number;
    errorRate: number;
    activeConnections: number;
  };
}

class InfrastructureManager {
  private healthCheckInterval: NodeJS.Timeout | null = null;
  private lastHealthCheck: InfrastructureHealth | null = null;
  private isInitialized = false;

  public async initialize(userId?: string): Promise<boolean> {
    if (this.isInitialized) {
      return true;
    }

    try {
      console.log('Initializing AuraMind infrastructure...');

      // Initialize monitoring
      monitoringService.setUserId(userId || '');
      
      // Initialize database
      const dbInitialized = await dbService.initialize();
      
      // Initialize WebSocket connection
      if (userId) {
        await wsService.connect(userId);
      }

      // Set up real-time sync listeners
      this.setupRealtimeSync();
      
      // Start health monitoring
      this.startHealthMonitoring();

      // Set up error handling
      this.setupGlobalErrorHandling();

      this.isInitialized = true;
      console.log('Infrastructure initialized successfully');
      
      return true;
    } catch (error) {
      console.error('Failed to initialize infrastructure:', error);
      monitoringService.captureError({
        message: 'Infrastructure initialization failed',
        severity: 'critical',
        context: { error: error.message }
      });
      
      return false;
    }
  }

  private setupRealtimeSync(): void {
    // Listen for WebSocket data sync events
    wsService.on('sync', (data) => {
      this.handleRealtimeSync(data);
    });

    // Listen for database changes
    window.addEventListener('auramind_data_sync', (event: any) => {
      this.handleDatabaseSync(event.detail);
    });

    // Set up periodic sync
    setInterval(() => {
      this.performPeriodicSync();
    }, 30000); // Every 30 seconds
  }

  private async handleRealtimeSync(data: any): Promise<void> {
    try {
      switch (data.type) {
        case 'task_update':
          await this.syncTasks(data.payload);
          break;
        case 'calendar_update':
          await this.syncCalendar(data.payload);
          break;
        case 'analytics_update':
          await this.syncAnalytics(data.payload);
          break;
        case 'profile_update':
          await this.syncProfile(data.payload);
          break;
      }

      // Clear related cache entries
      this.invalidateRelatedCache(data.type);
      
    } catch (error) {
      monitoringService.captureError({
        message: 'Failed to handle realtime sync',
        severity: 'medium',
        context: { data, error: error.message }
      });
    }
  }

  private async handleDatabaseSync(data: any): Promise<void> {
    // Handle database changes and update WebSocket if needed
    if (wsService.isConnected() && data.eventType !== 'local') {
      wsService.sendSync({
        type: 'database_change',
        payload: data
      });
    }
  }

  private async performPeriodicSync(): Promise<void> {
    if (!wsService.isConnected()) {
      return;
    }

    try {
      // Send periodic heartbeat with sync data
      const syncData = await this.collectSyncData();
      
      wsService.sendSync({
        type: 'periodic_sync',
        payload: syncData,
        timestamp: Date.now()
      });

    } catch (error) {
      console.warn('Periodic sync failed:', error);
    }
  }

  private async collectSyncData(): Promise<any> {
    return {
      cacheStats: {
        memory: memoryCache.getStats(),
        api: apiCache.getStats(),
        user: userCache.getStats(),
        persistent: persistentCache.getStats()
      },
      rateLimitStats: apiRateLimitService.getAllStats(),
      healthStatus: this.lastHealthCheck?.status || 'unknown'
    };
  }

  private invalidateRelatedCache(syncType: string): void {
    const cachePatterns: Record<string, RegExp[]> = {
      task_update: [/^tasks:/, /^user_data:/],
      calendar_update: [/^calendar:/, /^events:/],
      analytics_update: [/^analytics:/, /^metrics:/],
      profile_update: [/^profile:/, /^user:/]
    };

    const patterns = cachePatterns[syncType] || [];
    
    patterns.forEach(pattern => {
      [memoryCache, apiCache, userCache].forEach(cache => {
        const keys = cache.keys(pattern);
        keys.forEach(key => cache.delete(key));
      });
    });
  }

  private async syncTasks(payload: any): Promise<void> {
    // Update local task data
    await dbService.syncUserData({ tasks: payload.tasks });
    
    // Trigger UI update
    window.dispatchEvent(new CustomEvent('auramind_tasks_synced', {
      detail: payload
    }));
  }

  private async syncCalendar(payload: any): Promise<void> {
    await dbService.syncUserData({ calendar_events: payload.events });
    
    window.dispatchEvent(new CustomEvent('auramind_calendar_synced', {
      detail: payload
    }));
  }

  private async syncAnalytics(payload: any): Promise<void> {
    await dbService.syncUserData({ analytics_data: payload.data });
    
    window.dispatchEvent(new CustomEvent('auramind_analytics_synced', {
      detail: payload
    }));
  }

  private async syncProfile(payload: any): Promise<void> {
    await dbService.updateUserProfile(payload.profile);
    
    window.dispatchEvent(new CustomEvent('auramind_profile_synced', {
      detail: payload
    }));
  }

  private startHealthMonitoring(): void {
    this.healthCheckInterval = setInterval(async () => {
      const health = await this.performHealthCheck();
      this.lastHealthCheck = health;
      
      // Send health metrics
      monitoringService.recordGauge('infrastructure.health.overall', 
        health.status === 'healthy' ? 100 : health.status === 'degraded' ? 50 : 0
      );

      // Alert on critical status
      if (health.status === 'critical') {
        monitoringService.captureError({
          message: 'Infrastructure health is critical',
          severity: 'critical',
          context: { health }
        });
      }

    }, 60000); // Every minute
  }

  private async performHealthCheck(): Promise<InfrastructureHealth> {
    const services: InfrastructureHealth['services'] = {};
    
    // Check WebSocket
    services.websocket = {
      status: wsService.isConnected() ? 'up' : 'down',
      lastCheck: new Date()
    };

    // Check Database
    try {
      const start = performance.now();
      await dbService.getUserProfile();
      services.database = {
        status: 'up',
        lastCheck: new Date(),
        responseTime: performance.now() - start
      };
    } catch (error) {
      services.database = {
        status: 'down',
        lastCheck: new Date()
      };
    }

    // Check Cache Systems
    services.cache = {
      status: 'up',
      lastCheck: new Date()
    };

    // Check Rate Limiters
    services.rateLimiter = {
      status: 'up',
      lastCheck: new Date()
    };

    // Calculate overall health
    const upServices = Object.values(services).filter(s => s.status === 'up').length;
    const totalServices = Object.values(services).length;
    const healthRatio = upServices / totalServices;

    let overallStatus: InfrastructureHealth['status'] = 'healthy';
    if (healthRatio < 0.8) {
      overallStatus = 'degraded';
    }
    if (healthRatio < 0.5) {
      overallStatus = 'critical';
    }

    // Collect metrics
    const cacheStats = memoryCache.getStats();
    const systemHealth = monitoringService.getHealthStatus();

    return {
      status: overallStatus,
      services,
      metrics: {
        cacheHitRate: cacheStats.hitRate,
        averageResponseTime: systemHealth.responseTime,
        errorRate: systemHealth.errorRate,
        activeConnections: wsService.isConnected() ? 1 : 0
      }
    };
  }

  private setupGlobalErrorHandling(): void {
    // Enhanced error boundary for React
    window.addEventListener('error', (event) => {
      if (event.error?.message?.includes('ChunkLoadError')) {
        // Handle chunk loading errors (common in SPA deployments)
        window.location.reload();
      }
    });

    // Handle WebSocket errors
    wsService.on('error', (error) => {
      monitoringService.captureError({
        message: 'WebSocket error',
        severity: 'medium',
        context: { error }
      });
    });

    // Handle network errors
    window.addEventListener('offline', () => {
      this.handleNetworkOffline();
    });

    window.addEventListener('online', () => {
      this.handleNetworkOnline();
    });
  }

  private handleNetworkOffline(): void {
    console.log('Network offline - switching to offline mode');
    
    // Stop WebSocket
    wsService.disconnect();
    
    // Switch to offline-first caching
    persistentCache.set('offline_mode', true, 0); // No expiry
    
    monitoringService.recordMetric({
      name: 'network.status',
      value: 0,
      timestamp: Date.now(),
      type: 'gauge',
      tags: { status: 'offline' }
    });
  }

  private async handleNetworkOnline(): Promise<void> {
    console.log('Network online - resuming normal operation');
    
    // Remove offline mode flag
    persistentCache.delete('offline_mode');
    
    // Reconnect WebSocket
    const userId = (await dbService.getUserProfile())?.id;
    if (userId) {
      await wsService.connect(userId);
    }
    
    // Trigger data sync
    await this.performPeriodicSync();
    
    monitoringService.recordMetric({
      name: 'network.status',
      value: 1,
      timestamp: Date.now(),
      type: 'gauge',
      tags: { status: 'online' }
    });
  }

  // Public API Methods
  public getHealthStatus(): InfrastructureHealth | null {
    return this.lastHealthCheck;
  }

  public async createSystemBackup(): Promise<string | null> {
    try {
      const backup = await dbService.createBackup();
      
      if (backup) {
        monitoringService.recordMetric({
          name: 'backup.created',
          value: 1,
          timestamp: Date.now(),
          type: 'counter'
        });
      }
      
      return backup;
    } catch (error) {
      monitoringService.captureError({
        message: 'Failed to create system backup',
        severity: 'high',
        context: { error: error.message }
      });
      
      return null;
    }
  }

  public async optimizePerformance(): Promise<void> {
    console.log('Starting performance optimization...');
    
    // Clear old cache entries
    [memoryCache, apiCache, userCache].forEach(cache => {
      const stats = cache.getStats();
      if (stats.hitRate < 30) {
        cache.clear();
      }
    });

    // Reset rate limiters for better responsiveness
    apiRateLimitService.resetLimiter('api');
    
    // Trigger garbage collection if available
    if ((window as any).gc) {
      (window as any).gc();
    }

    console.log('Performance optimization completed');
  }

  public getMetrics(): any {
    return {
      monitoring: monitoringService.exportData(),
      cache: {
        memory: memoryCache.getStats(),
        api: apiCache.getStats(),
        user: userCache.getStats(),
        persistent: persistentCache.getStats()
      },
      rateLimiting: apiRateLimitService.getAllStats(),
      websocket: {
        connected: wsService.isConnected(),
        status: wsService.getConnectionStatus()
      },
      health: this.lastHealthCheck
    };
  }

  public async shutdown(): Promise<void> {
    console.log('Shutting down infrastructure...');
    
    // Stop health monitoring
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
    }

    // Disconnect WebSocket
    wsService.disconnect();

    // Clear caches
    [memoryCache, apiCache, userCache, persistentCache].forEach(cache => {
      if (cache.destroy) {
        cache.destroy();
      }
    });

    // Destroy rate limiters
    apiRateLimitService.destroy();
    clientRateLimiter.destroy();

    this.isInitialized = false;
    console.log('Infrastructure shutdown completed');
  }
}

export const infrastructureManager = new InfrastructureManager();

// Auto-initialize when imported
if (typeof window !== 'undefined') {
  // Initialize after DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      infrastructureManager.initialize().catch(console.error);
    });
  } else {
    infrastructureManager.initialize().catch(console.error);
  }
}
