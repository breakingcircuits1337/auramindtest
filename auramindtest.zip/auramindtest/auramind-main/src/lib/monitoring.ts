
interface PerformanceMetric {
  name: string;
  value: number;
  timestamp: number;
  tags?: Record<string, string>;
  type: 'timing' | 'counter' | 'gauge' | 'histogram';
}

interface ErrorReport {
  id: string;
  message: string;
  stack?: string;
  url: string;
  line?: number;
  column?: number;
  timestamp: number;
  userId?: string;
  sessionId: string;
  userAgent: string;
  context?: Record<string, any>;
  severity: 'low' | 'medium' | 'high' | 'critical';
}

interface SystemHealth {
  status: 'healthy' | 'degraded' | 'down';
  uptime: number;
  memoryUsage: number;
  responseTime: number;
  errorRate: number;
  timestamp: number;
}

class MonitoringService {
  private metrics: PerformanceMetric[] = [];
  private errors: ErrorReport[] = [];
  private sessionId: string;
  private userId: string | null = null;
  private startTime: number = Date.now();
  private performanceObserver: PerformanceObserver | null = null;

  constructor() {
    this.sessionId = this.generateSessionId();
    this.initializeErrorTracking();
    this.initializePerformanceTracking();
    this.startHealthMonitoring();
  }

  // Error Tracking
  private initializeErrorTracking(): void {
    // Global error handler
    window.addEventListener('error', (event) => {
      this.captureError({
        message: event.message,
        stack: event.error?.stack,
        url: event.filename,
        line: event.lineno,
        column: event.colno,
        severity: 'high',
        context: { type: 'javascript_error' }
      });
    });

    // Unhandled promise rejection handler
    window.addEventListener('unhandledrejection', (event) => {
      this.captureError({
        message: `Unhandled Promise Rejection: ${event.reason}`,
        stack: event.reason?.stack,
        url: window.location.href,
        severity: 'high',
        context: { 
          type: 'promise_rejection',
          reason: event.reason 
        }
      });
    });

    // React error boundary integration
    window.addEventListener('react-error', (event: any) => {
      this.captureError({
        message: event.detail.message,
        stack: event.detail.stack,
        url: window.location.href,
        severity: 'critical',
        context: {
          type: 'react_error',
          componentStack: event.detail.componentStack
        }
      });
    });
  }

  public captureError(errorData: Partial<ErrorReport>): string {
    const errorId = this.generateErrorId();
    
    const error: ErrorReport = {
      id: errorId,
      message: errorData.message || 'Unknown error',
      stack: errorData.stack,
      url: errorData.url || window.location.href,
      line: errorData.line,
      column: errorData.column,
      timestamp: Date.now(),
      userId: this.userId,
      sessionId: this.sessionId,
      userAgent: navigator.userAgent,
      context: errorData.context || {},
      severity: errorData.severity || 'medium'
    };

    this.errors.push(error);
    this.trimErrors();
    
    // Send to monitoring service
    this.sendErrorReport(error);
    
    // Log to console in development
    if (process.env.NODE_ENV === 'development') {
      console.error('Error captured:', error);
    }

    return errorId;
  }

  // Performance Tracking
  private initializePerformanceTracking(): void {
    if ('PerformanceObserver' in window) {
      this.performanceObserver = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          this.recordPerformanceEntry(entry);
        }
      });

      // Observe different types of performance entries
      try {
        this.performanceObserver.observe({ entryTypes: ['measure', 'navigation', 'resource', 'paint'] });
      } catch (e) {
        console.warn('Some performance entry types not supported');
      }
    }

    // Track custom metrics
    this.trackPageLoad();
    this.trackUserInteractions();
    this.trackNetworkRequests();
  }

  private recordPerformanceEntry(entry: PerformformanceEntry): void {
    const metric: PerformanceMetric = {
      name: entry.name,
      value: entry.duration || (entry as any).value || 0,
      timestamp: Date.now(),
      type: this.getMetricType(entry.entryType),
      tags: {
        entryType: entry.entryType,
        url: window.location.pathname
      }
    };

    this.recordMetric(metric);
  }

  public recordMetric(metric: PerformanceMetric): void {
    this.metrics.push(metric);
    this.trimMetrics();
    
    // Send high-priority metrics immediately
    if (metric.value > 3000 || metric.name.includes('error')) {
      this.sendMetric(metric);
    }
  }

  public startTimer(name: string): () => void {
    const startTime = performance.now();
    
    return () => {
      const duration = performance.now() - startTime;
      this.recordMetric({
        name,
        value: duration,
        timestamp: Date.now(),
        type: 'timing',
        tags: { custom: 'true' }
      });
    };
  }

  public incrementCounter(name: string, value: number = 1, tags?: Record<string, string>): void {
    this.recordMetric({
      name,
      value,
      timestamp: Date.now(),
      type: 'counter',
      tags
    });
  }

  public recordGauge(name: string, value: number, tags?: Record<string, string>): void {
    this.recordMetric({
      name,
      value,
      timestamp: Date.now(),
      type: 'gauge',
      tags
    });
  }

  // System Health Monitoring
  private startHealthMonitoring(): void {
    setInterval(() => {
      const health = this.getSystemHealth();
      this.recordMetric({
        name: 'system.health.response_time',
        value: health.responseTime,
        timestamp: Date.now(),
        type: 'gauge'
      });

      if (health.status !== 'healthy') {
        this.captureError({
          message: `System health degraded: ${health.status}`,
          severity: health.status === 'down' ? 'critical' : 'medium',
          context: { health }
        });
      }
    }, 60000); // Check every minute
  }

  private getSystemHealth(): SystemHealth {
    const now = Date.now();
    const uptime = now - this.startTime;
    
    // Estimate memory usage (basic approximation)
    const memoryUsage = (performance as any).memory?.usedJSHeapSize || 0;
    
    // Calculate response time based on recent metrics
    const recentTimings = this.metrics
      .filter(m => m.type === 'timing' && now - m.timestamp < 60000)
      .map(m => m.value);
    
    const responseTime = recentTimings.length > 0 
      ? recentTimings.reduce((sum, val) => sum + val, 0) / recentTimings.length
      : 0;

    // Calculate error rate
    const recentErrors = this.errors.filter(e => now - e.timestamp < 60000);
    const errorRate = (recentErrors.length / Math.max(1, recentTimings.length)) * 100;

    let status: SystemHealth['status'] = 'healthy';
    if (errorRate > 5 || responseTime > 5000) {
      status = 'degraded';
    }
    if (errorRate > 15 || responseTime > 10000) {
      status = 'down';
    }

    return {
      status,
      uptime,
      memoryUsage,
      responseTime,
      errorRate,
      timestamp: now
    };
  }

  // API Integration
  private async sendErrorReport(error: ErrorReport): Promise<void> {
    try {
      // In production, send to error tracking service
      if (process.env.NODE_ENV === 'production') {
        await fetch('/api/monitoring/errors', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(error)
        });
      }
    } catch (e) {
      console.error('Failed to send error report:', e);
    }
  }

  private async sendMetric(metric: PerformanceMetric): Promise<void> {
    try {
      if (process.env.NODE_ENV === 'production') {
        await fetch('/api/monitoring/metrics', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(metric)
        });
      }
    } catch (e) {
      console.error('Failed to send metric:', e);
    }
  }

  // Custom Tracking Methods
  private trackPageLoad(): void {
    window.addEventListener('load', () => {
      const timing = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
      
      this.recordMetric({
        name: 'page.load.total',
        value: timing.loadEventEnd - timing.navigationStart,
        timestamp: Date.now(),
        type: 'timing'
      });

      this.recordMetric({
        name: 'page.load.dom_content',
        value: timing.domContentLoadedEventEnd - timing.navigationStart,
        timestamp: Date.now(),
        type: 'timing'
      });
    });
  }

  private trackUserInteractions(): void {
    ['click', 'keydown', 'scroll'].forEach(eventType => {
      document.addEventListener(eventType, () => {
        this.incrementCounter(`user.interaction.${eventType}`);
      }, { passive: true });
    });
  }

  private trackNetworkRequests(): void {
    const originalFetch = window.fetch;
    
    window.fetch = async (...args) => {
      const start = performance.now();
      const url = typeof args[0] === 'string' ? args[0] : args[0].url;
      
      try {
        const response = await originalFetch(...args);
        const duration = performance.now() - start;
        
        this.recordMetric({
          name: 'network.request.duration',
          value: duration,
          timestamp: Date.now(),
          type: 'timing',
          tags: {
            url: url,
            status: response.status.toString(),
            method: args[1]?.method || 'GET'
          }
        });

        if (!response.ok) {
          this.incrementCounter('network.request.error', 1, {
            url: url,
            status: response.status.toString()
          });
        }

        return response;
      } catch (error) {
        const duration = performance.now() - start;
        
        this.recordMetric({
          name: 'network.request.duration',
          value: duration,
          timestamp: Date.now(),
          type: 'timing',
          tags: {
            url: url,
            status: 'error',
            method: args[1]?.method || 'GET'
          }
        });

        this.captureError({
          message: `Network request failed: ${url}`,
          severity: 'medium',
          context: { url, error: error.message }
        });

        throw error;
      }
    };
  }

  // Utility Methods
  private getMetricType(entryType: string): PerformanceMetric['type'] {
    switch (entryType) {
      case 'measure':
      case 'navigation':
      case 'resource':
        return 'timing';
      case 'paint':
        return 'gauge';
      default:
        return 'gauge';
    }
  }

  private trimMetrics(): void {
    if (this.metrics.length > 1000) {
      this.metrics = this.metrics.slice(-1000);
    }
  }

  private trimErrors(): void {
    if (this.errors.length > 100) {
      this.errors = this.errors.slice(-100);
    }
  }

  private generateSessionId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private generateErrorId(): string {
    return `err_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
  }

  // Public API
  public setUserId(userId: string): void {
    this.userId = userId;
  }

  public getMetrics(timeRange?: number): PerformanceMetric[] {
    const cutoff = timeRange ? Date.now() - timeRange : 0;
    return this.metrics.filter(m => m.timestamp > cutoff);
  }

  public getErrors(timeRange?: number): ErrorReport[] {
    const cutoff = timeRange ? Date.now() - timeRange : 0;
    return this.errors.filter(e => e.timestamp > cutoff);
  }

  public getHealthStatus(): SystemHealth {
    return this.getSystemHealth();
  }

  public exportData(): { metrics: PerformanceMetric[]; errors: ErrorReport[] } {
    return {
      metrics: [...this.metrics],
      errors: [...this.errors]
    };
  }
}

export const monitoringService = new MonitoringService();
