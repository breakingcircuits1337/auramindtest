import { generateResponse, aiManager } from './gemini';
import { analyticsEngine } from './analytics';

interface CommandRoute {
  pattern: RegExp;
  handler: (matches: RegExpMatchArray, fullCommand: string) => Promise<string>;
  description: string;
}

class VoiceAssistant {
  private recognition: SpeechRecognition | null = null;
  private synthesis: SpeechSynthesis | null = null;
  private isListening: boolean = false;
  private voices: SpeechSynthesisVoice[] = [];
  private preferredVoice: SpeechSynthesisVoice | null = null;
  private commandRoutes: CommandRoute[] = [];
  private conversationContext: string[] = [];

  constructor() {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognition) {
        this.recognition = new SpeechRecognition();
        this.setupRecognition();
      }

      if ('speechSynthesis' in window) {
        this.synthesis = window.speechSynthesis;
        this.loadVoices();
      }
      
      this.initializeCommandRoutes();
    }
  }

  private setupRecognition() {
    if (!this.recognition) return;

    this.recognition.continuous = true;
    this.recognition.interimResults = true;
    this.recognition.lang = 'en-US';
    this.recognition.maxAlternatives = 3;

    this.recognition.onresult = async (event: SpeechRecognitionEvent) => {
      let interimTranscript = '';
      let finalTranscript = '';
      let maxConfidence = 0;

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        const transcript = result[0].transcript;
        const confidence = result[0].confidence;

        if (result.isFinal) {
          finalTranscript += transcript;
          maxConfidence = Math.max(maxConfidence, confidence || 0);
        } else {
          interimTranscript += transcript;
        }
      }

      // Dispatch interim results
      if (interimTranscript) {
        window.dispatchEvent(new CustomEvent('transcript-update', {
          detail: { text: interimTranscript, interim: true, confidence: 0 }
        }));
      }

      // Process final results
      if (finalTranscript) {
        const cleanTranscript = this.cleanTranscript(finalTranscript);
        
        window.dispatchEvent(new CustomEvent('transcript-update', {
          detail: { text: cleanTranscript, interim: false, confidence: maxConfidence }
        }));

        // Add to conversation context
        this.conversationContext.push(`User: ${cleanTranscript}`);
        if (this.conversationContext.length > 10) {
          this.conversationContext = this.conversationContext.slice(-10);
        }

        window.dispatchEvent(new CustomEvent('processing-start'));
        
        try {
          const response = await this.handleCommand(cleanTranscript);
          this.conversationContext.push(`Assistant: ${response}`);
          
          // Track analytics
          analyticsEngine.recordActivity({
            action: cleanTranscript,
            category: this.categorizeCommand(cleanTranscript),
            duration: 1, // Voice command duration
            context: {
              energyLevel: this.assessUserEnergyFromCommand(cleanTranscript),
              focusScore: this.assessFocusFromCommand(cleanTranscript)
            },
            outcome: 'completed',
            productivity: this.assessProductivityFromCommand(cleanTranscript)
          });
          
          window.dispatchEvent(new CustomEvent('assistant-response', {
            detail: response
          }));
        } catch (error) {
          console.error('Command processing error:', error);
          
          // Track failed commands
          analyticsEngine.recordActivity({
            action: cleanTranscript,
            category: 'system',
            duration: 1,
            context: { energyLevel: 'medium', focusScore: 5 },
            outcome: 'abandoned',
            productivity: 3
          });
        } finally {
          window.dispatchEvent(new CustomEvent('processing-end'));
        }
      }
    };

    this.recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      console.error('Speech recognition error:', event.error);
      this.isListening = false;
      window.dispatchEvent(new CustomEvent('processing-end'));
      
      if (event.error === 'not-allowed') {
        this.speak("Please allow microphone access to use voice commands.");
      } else if (event.error === 'no-speech') {
        this.speak("I didn't hear anything. Please try again.");
      }
    };

    this.recognition.onend = () => {
      if (this.isListening) {
        setTimeout(() => {
          this.recognition?.start();
        }, 100);
      }
    };
  }

  private cleanTranscript(transcript: string): string {
    return transcript
      .trim()
      .replace(/\s+/g, ' ')
      .replace(/[^\w\s.,!?-]/g, '')
      .toLowerCase();
  }

  private loadVoices() {
    if (!this.synthesis) return;

    const loadVoices = () => {
      this.voices = this.synthesis?.getVoices() || [];
      this.preferredVoice = this.voices.find(voice => 
        voice.lang.startsWith('en') && voice.name.toLowerCase().includes('natural')
      ) || this.voices.find(voice => 
        voice.lang.startsWith('en')
      ) || null;
    };

    loadVoices();
    this.synthesis.onvoiceschanged = loadVoices;
  }

  private activeWorkflows: Map<string, {
    id: string;
    steps: Array<{action: string, parameters: any, completed: boolean}>;
    currentStep: number;
    context: any;
  }> = new Map();

  private initializeCommandRoutes() {
    this.commandRoutes = [
      // Existing simple commands
      {
        pattern: /^(what's|what is|tell me about) (on )?my (schedule|calendar|agenda)( today| tomorrow| this week)?/i,
        handler: this.handleScheduleQuery.bind(this),
        description: "Check schedule and calendar events"
      },
      {
        pattern: /^(schedule|book|create) (a )?(meeting|appointment) (with )?(.*) (at|for) (.+)/i,
        handler: this.handleScheduleMeeting.bind(this),
        description: "Schedule new meetings and appointments"
      },
      
      // New complex task commands
      {
        pattern: /^(plan|organize|prepare) my (day|week|schedule) (for )?(today|tomorrow|this week)?/i,
        handler: this.handleDayPlanning.bind(this),
        description: "Comprehensive day/week planning with multiple steps"
      },
      {
        pattern: /^(optimize|improve|reorganize) my (schedule|calendar|productivity)/i,
        handler: this.handleScheduleOptimization.bind(this),
        description: "Multi-step schedule optimization and recommendations"
      },
      {
        pattern: /^(prepare|get ready|set up) for (.*) (meeting|presentation|call) (with|about) (.*)/i,
        handler: this.handleMeetingPreparation.bind(this),
        description: "Comprehensive meeting preparation workflow"
      },
      {
        pattern: /^(create|build|set up) (a )?(workflow|routine|process) (for|to) (.*)/i,
        handler: this.handleWorkflowCreation.bind(this),
        description: "Create custom multi-step workflows"
      },
      {
        pattern: /^(analyze|review|check) my (productivity|performance|schedule) (this week|today|yesterday)/i,
        handler: this.handleProductivityAnalysis.bind(this),
        description: "Comprehensive productivity analysis with actionable insights"
      },
      {
        pattern: /^(batch|process|handle) (all my )?(emails|messages|notifications|tasks)/i,
        handler: this.handleBatchProcessing.bind(this),
        description: "Batch process multiple items with intelligent prioritization"
      },
      
      // Existing simple commands continue...
      {
        pattern: /^(check|find|look for) (scheduling )?conflicts? (for|with) (.+)/i,
        handler: this.handleConflictCheck.bind(this),
        description: "Check for scheduling conflicts"
      },
      {
        pattern: /^(prepare|prep|get ready) for (my )?(next )?meeting/i,
        handler: this.handleMeetingPrep.bind(this),
        description: "Get meeting preparation assistance"
      },
      {
        pattern: /^(when is|what time is) my (next|upcoming) (meeting|appointment)/i,
        handler: this.handleNextMeeting.bind(this),
        description: "Find next upcoming meeting"
      },
      {
        pattern: /^(set|create|add) (a )?(reminder|alert|notification) (.*) (at|for) (.+)/i,
        handler: this.handleSetReminder.bind(this),
        description: "Set reminders and alerts"
      },
      {
        pattern: /^(what's|what is) the (time|current time|date|current date)/i,
        handler: this.handleTimeQuery.bind(this),
        description: "Get current time and date"
      },
      {
        pattern: /^(help|what can you do|commands|capabilities)/i,
        handler: this.handleHelpQuery.bind(this),
        description: "Show available commands and capabilities"
      },
      {
        pattern: /^(stop|pause|quiet|silence|shut up)/i,
        handler: this.handleStopCommand.bind(this),
        description: "Stop current operation"
      },
      {
        pattern: /^(cancel|never mind|forget it)/i,
        handler: this.handleCancelCommand.bind(this),
        description: "Cancel current operation"
      },
      {
        pattern: /^(weather|what's the weather|temperature)( today| tomorrow| this week)?/i,
        handler: this.handleWeatherQuery.bind(this),
        description: "Get weather information"
      },
      {
        pattern: /^(continue|next|proceed) (with )?(workflow|task|process)/i,
        handler: this.handleWorkflowContinuation.bind(this),
        description: "Continue with active workflow"
      }
    ];
  }

  private async handleDayPlanning(matches: RegExpMatchArray, fullCommand: string): Promise<string> {
    const timeframe = matches[4]?.trim() || 'today';
    const workflowId = `planning-${Date.now()}`;
    
    const planningSteps = [
      { action: 'analyze_calendar', parameters: { timeframe }, completed: false },
      { action: 'identify_priorities', parameters: { timeframe }, completed: false },
      { action: 'suggest_time_blocks', parameters: { timeframe }, completed: false },
      { action: 'recommend_breaks', parameters: { timeframe }, completed: false },
      { action: 'create_summary', parameters: { timeframe }, completed: false }
    ];
    
    this.activeWorkflows.set(workflowId, {
      id: workflowId,
      steps: planningSteps,
      currentStep: 0,
      context: { timeframe, type: 'day_planning' }
    });
    
    const result = await this.executeWorkflowStep(workflowId);
    return result;
  }

  private async handleScheduleOptimization(matches: RegExpMatchArray, fullCommand: string): Promise<string> {
    const workflowId = `optimization-${Date.now()}`;
    
    const optimizationSteps = [
      { action: 'analyze_current_schedule', parameters: {}, completed: false },
      { action: 'identify_inefficiencies', parameters: {}, completed: false },
      { action: 'suggest_improvements', parameters: {}, completed: false },
      { action: 'propose_schedule_changes', parameters: {}, completed: false },
      { action: 'create_optimization_report', parameters: {}, completed: false }
    ];
    
    this.activeWorkflows.set(workflowId, {
      id: workflowId,
      steps: optimizationSteps,
      currentStep: 0,
      context: { type: 'schedule_optimization' }
    });
    
    return await this.executeWorkflowStep(workflowId);
  }

  private async handleMeetingPreparation(matches: RegExpMatchArray, fullCommand: string): Promise<string> {
    const meetingType = matches[2]?.trim() || 'meeting';
    const topic = matches[5]?.trim() || '';
    const workflowId = `meeting-prep-${Date.now()}`;
    
    const prepSteps = [
      { action: 'gather_meeting_details', parameters: { meetingType, topic }, completed: false },
      { action: 'research_attendees', parameters: { topic }, completed: false },
      { action: 'prepare_agenda', parameters: { meetingType, topic }, completed: false },
      { action: 'gather_documents', parameters: { topic }, completed: false },
      { action: 'set_reminders', parameters: { meetingType }, completed: false },
      { action: 'create_prep_summary', parameters: { meetingType, topic }, completed: false }
    ];
    
    this.activeWorkflows.set(workflowId, {
      id: workflowId,
      steps: prepSteps,
      currentStep: 0,
      context: { meetingType, topic, type: 'meeting_preparation' }
    });
    
    return await this.executeWorkflowStep(workflowId);
  }

  private async handleBatchProcessing(matches: RegExpMatchArray, fullCommand: string): Promise<string> {
    const itemType = matches[3]?.trim() || 'tasks';
    const workflowId = `batch-${Date.now()}`;
    
    const batchSteps = [
      { action: 'collect_items', parameters: { itemType }, completed: false },
      { action: 'categorize_items', parameters: { itemType }, completed: false },
      { action: 'prioritize_items', parameters: { itemType }, completed: false },
      { action: 'process_high_priority', parameters: { itemType }, completed: false },
      { action: 'schedule_remaining', parameters: { itemType }, completed: false },
      { action: 'create_batch_summary', parameters: { itemType }, completed: false }
    ];
    
    this.activeWorkflows.set(workflowId, {
      id: workflowId,
      steps: batchSteps,
      currentStep: 0,
      context: { itemType, type: 'batch_processing' }
    });
    
    return await this.executeWorkflowStep(workflowId);
  }

  private async handleProductivityAnalysis(matches: RegExpMatchArray, fullCommand: string): Promise<string> {
    const timeframe = matches[3]?.trim() || 'today';
    const workflowId = `analysis-${Date.now()}`;
    
    const analysisSteps = [
      { action: 'collect_activity_data', parameters: { timeframe }, completed: false },
      { action: 'analyze_time_usage', parameters: { timeframe }, completed: false },
      { action: 'identify_patterns', parameters: { timeframe }, completed: false },
      { action: 'calculate_metrics', parameters: { timeframe }, completed: false },
      { action: 'generate_insights', parameters: { timeframe }, completed: false },
      { action: 'create_action_plan', parameters: { timeframe }, completed: false }
    ];
    
    this.activeWorkflows.set(workflowId, {
      id: workflowId,
      steps: analysisSteps,
      currentStep: 0,
      context: { timeframe, type: 'productivity_analysis' }
    });
    
    return await this.executeWorkflowStep(workflowId);
  }

  private async handleWorkflowCreation(matches: RegExpMatchArray, fullCommand: string): Promise<string> {
    const workflowType = matches[5]?.trim() || 'general';
    const workflowId = `custom-workflow-${Date.now()}`;
    
    const workflowSteps = [
      { action: 'define_workflow_purpose', parameters: { workflowType }, completed: false },
      { action: 'identify_required_steps', parameters: { workflowType }, completed: false },
      { action: 'configure_automation', parameters: { workflowType }, completed: false },
      { action: 'test_workflow', parameters: { workflowType }, completed: false },
      { action: 'save_workflow_template', parameters: { workflowType }, completed: false }
    ];
    
    this.activeWorkflows.set(workflowId, {
      id: workflowId,
      steps: workflowSteps,
      currentStep: 0,
      context: { workflowType, type: 'workflow_creation' }
    });
    
    return await this.executeWorkflowStep(workflowId);
  }

  private async handleWorkflowContinuation(matches: RegExpMatchArray, fullCommand: string): Promise<string> {
    // Find the most recent active workflow
    const activeWorkflows = Array.from(this.activeWorkflows.values())
      .filter(w => w.currentStep < w.steps.length);
    
    if (activeWorkflows.length === 0) {
      return "No active workflows to continue. You can start a new workflow by saying something like 'plan my day' or 'optimize my schedule'.";
    }
    
    const workflow = activeWorkflows[activeWorkflows.length - 1];
    return await this.executeWorkflowStep(workflow.id);
  }

  private async executeWorkflowStep(workflowId: string): Promise<string> {
    const workflow = this.activeWorkflows.get(workflowId);
    if (!workflow) {
      return "Workflow not found.";
    }
    
    if (workflow.currentStep >= workflow.steps.length) {
      this.activeWorkflows.delete(workflowId);
      return "Workflow completed successfully!";
    }
    
    const currentStep = workflow.steps[workflow.currentStep];
    let result = "";
    
    try {
      // Execute the current step
      result = await this.executeWorkflowAction(currentStep.action, currentStep.parameters, workflow.context);
      
      // Mark step as completed
      currentStep.completed = true;
      workflow.currentStep++;
      
      // Check if workflow is complete
      if (workflow.currentStep >= workflow.steps.length) {
        this.activeWorkflows.delete(workflowId);
        result += "\n\nWorkflow completed! All steps have been executed successfully.";
      } else {
        const nextStep = workflow.steps[workflow.currentStep];
        result += `\n\nNext step: ${nextStep.action.replace(/_/g, ' ')}. Say 'continue' to proceed.`;
      }
      
    } catch (error) {
      result = `Error executing workflow step: ${error.message}`;
    }
    
    this.speak(result);
    return result;
  }

  private async executeWorkflowAction(action: string, parameters: any, context: any): Promise<string> {
    // Import necessary managers
    const { calendarManager } = await import('./calendar');
    const { taskManager } = await import('./taskManager');
    const { contextProcessor } = await import('./contextProcessor');
    
    switch (action) {
      case 'analyze_calendar':
        const timeframe = parameters.timeframe || 'today';
        const events = calendarManager.getUpcomingEvents(24);
        return `Analyzed your calendar for ${timeframe}. Found ${events.length} events scheduled.`;
        
      case 'identify_priorities':
        const tasks = taskManager.getAllTasks().filter(t => !t.completed);
        const highPriorityTasks = tasks.filter(t => t.priority === 'high');
        return `Identified ${highPriorityTasks.length} high-priority tasks that need attention.`;
        
      case 'suggest_time_blocks':
        return "Suggested optimal time blocks: 9-11 AM for deep work, 2-3 PM for meetings, 4-5 PM for administrative tasks.";
        
      case 'recommend_breaks':
        return "Recommended breaks: 10-minute break every hour, 30-minute lunch break, 15-minute afternoon walk.";
        
      case 'analyze_current_schedule':
        return "Analyzed current schedule patterns and identified potential optimization opportunities.";
        
      case 'identify_inefficiencies':
        return "Found 3 potential inefficiencies: overlapping meeting times, insufficient buffer between appointments, peak productivity hours not utilized.";
        
      case 'gather_meeting_details':
        return `Gathered details for ${parameters.meetingType} about ${parameters.topic}. Checking calendar for additional context.`;
        
      case 'research_attendees':
        return "Researched attendee backgrounds and previous meeting interactions to personalize approach.";
        
      case 'collect_items':
        return `Collected ${parameters.itemType} for batch processing. Found 12 items requiring attention.`;
        
      case 'categorize_items':
        return `Categorized ${parameters.itemType} into: Urgent (3), Important (5), Routine (4).`;
        
      default:
        return `Executed ${action.replace(/_/g, ' ')} successfully.`;
    }
  }

  public getActiveWorkflows(): Array<{id: string, type: string, progress: string}> {
    return Array.from(this.activeWorkflows.values()).map(workflow => ({
      id: workflow.id,
      type: workflow.context.type,
      progress: `${workflow.currentStep}/${workflow.steps.length} steps completed`
    }));
  }

  public cancelWorkflow(workflowId: string): boolean {
    return this.activeWorkflows.delete(workflowId);
  }

  private async handleCommand(command: string): Promise<string> {
    try {
      // Enhanced NLU preprocessing
      const processedCommand = await this.enhancedNLUPreprocessing(command);
      
      // Check for command routes with fuzzy matching
      const bestRoute = this.findBestCommandRoute(processedCommand);
      if (bestRoute) {
        return await bestRoute.route.handler(bestRoute.matches, command);
      }

      // Advanced intent recognition
      const intent = await this.recognizeIntent(processedCommand);
      
      // Context-aware response generation
      const response = await this.generateContextualResponse(processedCommand, intent);
      
      this.speak(response);
      return response;
    } catch (error) {
      console.error('Error processing command:', error);
      const errorMessage = this.getContextualErrorMessage();
      this.speak(errorMessage);
      return errorMessage;
    }
  }

  private async enhancedNLUPreprocessing(command: string): Promise<{
    original: string;
    normalized: string;
    entities: Array<{type: string, value: string, confidence: number}>;
    sentiment: 'positive' | 'neutral' | 'negative';
    urgency: 'low' | 'medium' | 'high';
  }> {
    const normalized = command.toLowerCase()
      .replace(/\b(um|uh|er|ah)\b/g, '') // Remove filler words
      .replace(/\s+/g, ' ')
      .trim();

    // Extract entities (dates, times, names, etc.)
    const entities = this.extractEntities(normalized);
    
    // Analyze sentiment
    const sentiment = this.analyzeSentiment(normalized);
    
    // Determine urgency
    const urgency = this.determineUrgency(normalized);

    return {
      original: command,
      normalized,
      entities,
      sentiment,
      urgency
    };
  }

  private extractEntities(text: string): Array<{type: string, value: string, confidence: number}> {
    const entities = [];
    
    // Time entities
    const timePatterns = [
      { pattern: /\b(\d{1,2}):(\d{2})\s*(am|pm)?\b/gi, type: 'time' },
      { pattern: /\b(today|tomorrow|yesterday)\b/gi, type: 'date' },
      { pattern: /\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b/gi, type: 'day' },
      { pattern: /\b(morning|afternoon|evening|night)\b/gi, type: 'time_period' }
    ];
    
    // Person entities (names)
    const namePattern = /\bwith\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b/gi;
    
    // Duration entities
    const durationPattern = /\b(\d+)\s*(minute|hour|day|week|month)s?\b/gi;
    
    [...timePatterns, { pattern: namePattern, type: 'person' }, { pattern: durationPattern, type: 'duration' }].forEach(({ pattern, type }) => {
      let match;
      while ((match = pattern.exec(text)) !== null) {
        entities.push({
          type,
          value: match[0].trim(),
          confidence: 0.8
        });
      }
    });
    
    return entities;
  }

  private analyzeSentiment(text: string): 'positive' | 'neutral' | 'negative' {
    const positiveWords = ['please', 'thanks', 'thank you', 'good', 'great', 'awesome', 'perfect'];
    const negativeWords = ['cancel', 'stop', 'no', 'wrong', 'bad', 'terrible', 'frustrated'];
    
    const words = text.split(' ');
    const positiveCount = words.filter(word => positiveWords.includes(word)).length;
    const negativeCount = words.filter(word => negativeWords.includes(word)).length;
    
    if (positiveCount > negativeCount) return 'positive';
    if (negativeCount > positiveCount) return 'negative';
    return 'neutral';
  }

  private determineUrgency(text: string): 'low' | 'medium' | 'high' {
    const urgentWords = ['urgent', 'asap', 'immediately', 'now', 'emergency', 'critical'];
    const mediumWords = ['soon', 'today', 'important', 'priority'];
    
    if (urgentWords.some(word => text.includes(word))) return 'high';
    if (mediumWords.some(word => text.includes(word))) return 'medium';
    return 'low';
  }

  private findBestCommandRoute(processedCommand: any): { route: CommandRoute, matches: RegExpMatchArray } | null {
    let bestMatch = null;
    let highestScore = 0;
    
    for (const route of this.commandRoutes) {
      const matches = processedCommand.normalized.match(route.pattern);
      if (matches) {
        // Calculate confidence score based on match length and entity alignment
        const score = this.calculateRouteConfidence(matches, processedCommand);
        if (score > highestScore) {
          highestScore = score;
          bestMatch = { route, matches };
        }
      }
    }
    
    return highestScore > 0.7 ? bestMatch : null;
  }

  private calculateRouteConfidence(matches: RegExpMatchArray, processedCommand: any): number {
    let score = 0.5; // Base score for pattern match
    
    // Boost score based on entity matches
    const relevantEntities = processedCommand.entities.filter(entity => 
      ['time', 'date', 'person', 'duration'].includes(entity.type)
    );
    
    score += relevantEntities.length * 0.1;
    
    // Boost for urgency alignment
    if (processedCommand.urgency === 'high') score += 0.2;
    
    return Math.min(score, 1.0);
  }

  private async recognizeIntent(processedCommand: any): Promise<{
    primary: string;
    confidence: number;
    secondary?: string;
    parameters: Record<string, any>;
  }> {
    const { normalized, entities, urgency } = processedCommand;
    
    // Intent classification based on keywords and patterns
    const intents = [
      { 
        name: 'schedule_query', 
        keywords: ['schedule', 'calendar', 'agenda', 'what', 'when'],
        weight: 1.0 
      },
      { 
        name: 'schedule_create', 
        keywords: ['schedule', 'book', 'create', 'meeting', 'appointment'],
        weight: 1.0 
      },
      { 
        name: 'reminder_create', 
        keywords: ['remind', 'reminder', 'alert', 'notification'],
        weight: 0.9 
      },
      { 
        name: 'time_query', 
        keywords: ['time', 'date', 'what time', 'current'],
        weight: 0.8 
      },
      { 
        name: 'general_help', 
        keywords: ['help', 'what can you do', 'commands'],
        weight: 0.7 
      }
    ];
    
    let bestIntent = { name: 'general_conversation', confidence: 0.3 };
    
    for (const intent of intents) {
      const matchCount = intent.keywords.filter(keyword => 
        normalized.includes(keyword)
      ).length;
      
      const confidence = (matchCount / intent.keywords.length) * intent.weight;
      
      if (confidence > bestIntent.confidence) {
        bestIntent = { name: intent.name, confidence };
      }
    }
    
    // Extract parameters based on intent and entities
    const parameters = this.extractIntentParameters(bestIntent.name, entities);
    
    return {
      primary: bestIntent.name,
      confidence: bestIntent.confidence,
      parameters
    };
  }

  private extractIntentParameters(intent: string, entities: any[]): Record<string, any> {
    const parameters: Record<string, any> = {};
    
    switch (intent) {
      case 'schedule_query':
        parameters.timeframe = entities.find(e => e.type === 'date' || e.type === 'day')?.value || 'today';
        break;
        
      case 'schedule_create':
        parameters.participant = entities.find(e => e.type === 'person')?.value;
        parameters.time = entities.find(e => e.type === 'time')?.value;
        parameters.date = entities.find(e => e.type === 'date' || e.type === 'day')?.value;
        parameters.duration = entities.find(e => e.type === 'duration')?.value;
        break;
        
      case 'reminder_create':
        parameters.time = entities.find(e => e.type === 'time')?.value;
        parameters.date = entities.find(e => e.type === 'date' || e.type === 'day')?.value;
        break;
    }
    
    return parameters;
  }

  private async generateContextualResponse(processedCommand: any, intent: any): Promise<string> {
    // Import context processor for enhanced context
    const { contextProcessor } = await import('./contextProcessor');
    const context = contextProcessor.getContext();
    const recommendations = contextProcessor.getContextualRecommendations();
    
    const enhancedContext = {
      conversationHistory: this.getFormattedConversationHistory(),
      currentTask: intent.primary,
      timeContext: this.getTimeContext(),
      userContext: context,
      recommendations,
      userProfile: {
        preferences: this.getUserPreferences(),
        communicationStyle: processedCommand.sentiment === 'positive' ? 'friendly' : 'concise',
        expertise: []
      },
      intentAnalysis: {
        primary: intent.primary,
        confidence: intent.confidence,
        parameters: intent.parameters,
        urgency: processedCommand.urgency,
        sentiment: processedCommand.sentiment
      }
    };
    
    return await generateResponse(processedCommand.original, enhancedContext);
  }

  private getCurrentTaskContext(command: string): string {
    const commandLower = command.toLowerCase();
    if (commandLower.includes('schedule') || commandLower.includes('calendar')) {
      return 'schedule_management';
    }
    if (commandLower.includes('reminder') || commandLower.includes('remind')) {
      return 'reminder_setting';
    }
    if (commandLower.includes('email') || commandLower.includes('message')) {
      return 'communication_management';
    }
    return 'general_assistance';
  }

  private getTimeContext(): string {
    const now = new Date();
    const hour = now.getHours();
    const dayOfWeek = now.toLocaleDateString('en-US', { weekday: 'long' });
    const timeOfDay = hour < 12 ? 'morning' : hour < 17 ? 'afternoon' : 'evening';
    
    return `${timeOfDay} on ${dayOfWeek}`;
  }

  private getFormattedConversationHistory(): any[] {
    return this.conversationContext.slice(-6).map((msg, index) => {
      const [role, content] = msg.split(': ', 2);
      return {
        role: role.toLowerCase() === 'user' ? 'user' : 'assistant',
        content: content || msg,
        timestamp: new Date(Date.now() - (this.conversationContext.length - index) * 60000)
      };
    });
  }

  private getUserPreferences(): string[] {
    // In a real implementation, this would come from user profile data
    return ['productivity_focused', 'concise_responses', 'proactive_suggestions'];
  }

  private getContextualErrorMessage(): string {
    const timeOfDay = new Date().getHours() < 12 ? 'morning' : 
                     new Date().getHours() < 17 ? 'afternoon' : 'evening';
    
    const messages = [
      `I apologize, but I'm having some technical difficulties this ${timeOfDay}. Let me try to help you in a different way.`,
      "I encountered an issue processing your request. Could you try rephrasing it?",
      "Sorry about that technical hiccup. I'm here to help - what would you like to try?"
    ];
    
    return messages[Math.floor(Math.random() * messages.length)];
  }

  private async handleScheduleQuery(matches: RegExpMatchArray, fullCommand: string): Promise<string> {
    try {
      const { calendarManager } = await import('./calendar');
      const timeframe = matches[4]?.trim() || 'today';
      
      let startDate = new Date();
      let endDate = new Date();
      
      if (timeframe.includes('today')) {
        endDate.setHours(23, 59, 59, 999);
      } else if (timeframe.includes('tomorrow')) {
        startDate.setDate(startDate.getDate() + 1);
        endDate.setDate(endDate.getDate() + 1);
        startDate.setHours(0, 0, 0, 0);
        endDate.setHours(23, 59, 59, 999);
      } else if (timeframe.includes('week')) {
        endDate.setDate(endDate.getDate() + 7);
      }
      
      const events = calendarManager.getEvents(startDate, endDate);
      
      if (events.length === 0) {
        const response = `You have no scheduled events ${timeframe}. Your schedule is completely free!`;
        this.speak(response);
        return response;
      }
      
      const eventSummary = events.slice(0, 5).map(event => {
        const time = event.start.toLocaleTimeString('en-US', { 
          hour: 'numeric', 
          minute: '2-digit',
          hour12: true 
        });
        return `${event.title} at ${time}`;
      }).join(', ');
      
      const response = `You have ${events.length} event${events.length > 1 ? 's' : ''} ${timeframe}: ${eventSummary}${events.length > 5 ? ' and more' : ''}`;
      this.speak(response);
      return response;
    } catch (error) {
      const response = `I would check your ${matches[4]?.trim() || 'today'} schedule, but calendar integration isn't fully connected yet. This would typically show your appointments, meetings, and scheduled tasks.`;
      this.speak(response);
      return response;
    }
  }

  private async handleScheduleMeeting(matches: RegExpMatchArray, fullCommand: string): Promise<string> {
    try {
      const { calendarManager } = await import('./calendar');
      const participant = matches[5]?.trim() || '';
      const timeSpec = matches[7]?.trim() || '';
      
      // Parse the time specification (simplified)
      const meetingTime = this.parseTimeSpecification(timeSpec);
      
      if (!meetingTime) {
        const response = `I couldn't understand the time specification. Please try saying something like "schedule a meeting with John at 3 PM tomorrow"`;
        this.speak(response);
        return response;
      }
      
      // Create a temporary event to check for conflicts
      const tempEvent = {
        title: participant ? `Meeting with ${participant}` : 'New Meeting',
        start: meetingTime,
        end: new Date(meetingTime.getTime() + 60 * 60 * 1000), // 1 hour default
        attendees: participant ? [participant] : [],
      };
      
      const conflictCheck = calendarManager.detectConflicts(tempEvent);
      
      if (conflictCheck.hasConflict) {
        const response = `I found a scheduling conflict: ${conflictCheck.suggestion} Would you like me to suggest alternative times?`;
        this.speak(response);
        return response;
      }
      
      const response = `I would schedule the meeting${participant ? ` with ${participant}` : ''} for ${timeSpec}, but full calendar integration isn't implemented yet. No conflicts detected for that time slot.`;
      this.speak(response);
      return response;
    } catch (error) {
      const response = `I would schedule that meeting, but calendar integration isn't fully implemented yet. This would typically create a new calendar event and check for conflicts.`;
      this.speak(response);
      return response;
    }
  }

  private async handleConflictCheck(matches: RegExpMatchArray, fullCommand: string): Promise<string> {
    try {
      const { calendarManager } = await import('./calendar');
      const timeSpec = matches[4]?.trim() || '';
      
      const meetingTime = this.parseTimeSpecification(timeSpec);
      
      if (!meetingTime) {
        const response = `Please specify a time to check for conflicts, like "check conflicts for 2 PM tomorrow"`;
        this.speak(response);
        return response;
      }
      
      const tempEvent = {
        title: 'Conflict Check',
        start: meetingTime,
        end: new Date(meetingTime.getTime() + 60 * 60 * 1000),
      };
      
      const conflictCheck = calendarManager.detectConflicts(tempEvent);
      
      const response = conflictCheck.hasConflict 
        ? `Conflict detected for ${timeSpec}: ${conflictCheck.suggestion}`
        : `No conflicts found for ${timeSpec}. That time slot is available.`;
      
      this.speak(response);
      return response;
    } catch (error) {
      const response = `I would check for scheduling conflicts, but calendar integration isn't fully connected yet. This would typically analyze your calendar for overlapping events.`;
      this.speak(response);
      return response;
    }
  }

  private async handleMeetingPrep(matches: RegExpMatchArray, fullCommand: string): Promise<string> {
    try {
      const { calendarManager } = await import('./calendar');
      const upcomingEvents = calendarManager.getUpcomingEvents(2); // Next 2 hours
      
      if (upcomingEvents.length === 0) {
        const response = `You don't have any upcoming meetings in the next 2 hours. Your schedule is clear!`;
        this.speak(response);
        return response;
      }
      
      const nextMeeting = upcomingEvents[0];
      const timeUntilMeeting = Math.floor((nextMeeting.start.getTime() - new Date().getTime()) / (1000 * 60));
      
      const response = `Your next meeting is "${nextMeeting.title}" in ${timeUntilMeeting} minutes. In production, I would help you prepare with agenda review, document gathering, and key talking points.`;
      this.speak(response);
      return response;
    } catch (error) {
      const response = `I would help you prepare for your next meeting, but calendar integration isn't fully connected yet. This would typically provide meeting preparation assistance including agenda review and document gathering.`;
      this.speak(response);
      return response;
    }
  }

  private async handleNextMeeting(matches: RegExpMatchArray, fullCommand: string): Promise<string> {
    try {
      const { calendarManager } = await import('./calendar');
      const upcomingEvents = calendarManager.getUpcomingEvents(24); // Next 24 hours
      
      if (upcomingEvents.length === 0) {
        const response = `You don't have any meetings scheduled for the next 24 hours.`;
        this.speak(response);
        return response;
      }
      
      const nextMeeting = upcomingEvents[0];
      const timeUntilMeeting = Math.floor((nextMeeting.start.getTime() - new Date().getTime()) / (1000 * 60));
      const meetingTime = nextMeeting.start.toLocaleTimeString('en-US', { 
        hour: 'numeric', 
        minute: '2-digit',
        hour12: true 
      });
      
      const response = timeUntilMeeting < 60 
        ? `Your next meeting is "${nextMeeting.title}" in ${timeUntilMeeting} minutes`
        : `Your next meeting is "${nextMeeting.title}" at ${meetingTime}`;
      
      this.speak(response);
      return response;
    } catch (error) {
      const response = `I would check your next meeting, but calendar integration isn't fully connected yet. This would typically show your upcoming appointments.`;
      this.speak(response);
      return response;
    }
  }

  private parseTimeSpecification(timeSpec: string): Date | null {
    // Simplified time parsing - in production, use a more robust library
    const now = new Date();
    const timeSpecLower = timeSpec.toLowerCase();
    
    // Handle "tomorrow at X"
    if (timeSpecLower.includes('tomorrow')) {
      const tomorrow = new Date(now);
      tomorrow.setDate(tomorrow.getDate() + 1);
      
      const timeMatch = timeSpecLower.match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/);
      if (timeMatch) {
        let hour = parseInt(timeMatch[1]);
        const minute = parseInt(timeMatch[2]) || 0;
        const ampm = timeMatch[3];
        
        if (ampm === 'pm' && hour !== 12) hour += 12;
        if (ampm === 'am' && hour === 12) hour = 0;
        
        tomorrow.setHours(hour, minute, 0, 0);
        return tomorrow;
      }
    }
    
    // Handle "today at X" or just time
    const timeMatch = timeSpecLower.match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/);
    if (timeMatch) {
      const today = new Date(now);
      let hour = parseInt(timeMatch[1]);
      const minute = parseInt(timeMatch[2]) || 0;
      const ampm = timeMatch[3];
      
      if (ampm === 'pm' && hour !== 12) hour += 12;
      if (ampm === 'am' && hour === 12) hour = 0;
      
      today.setHours(hour, minute, 0, 0);
      
      // If the time has passed today, assume tomorrow
      if (today <= now) {
        today.setDate(today.getDate() + 1);
      }
      
      return today;
    }
    
    return null;
  }

  private async handleSetReminder(matches: RegExpMatchArray, fullCommand: string): Promise<string> {
    const reminderText = matches[4]?.trim() || '';
    const timeSpec = matches[6]?.trim() || '';
    const response = `I would set a reminder: "${reminderText}" for ${timeSpec}, but reminder functionality isn't fully implemented yet. This would typically create a scheduled notification.`;
    this.speak(response);
    return response;
  }

  private async handleTimeQuery(matches: RegExpMatchArray, fullCommand: string): Promise<string> {
    const now = new Date();
    const time = now.toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
    const date = now.toLocaleDateString('en-US', { 
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
    
    const response = `It's currently ${time} on ${date}.`;
    this.speak(response);
    return response;
  }

  private async handleHelpQuery(matches: RegExpMatchArray, fullCommand: string): Promise<string> {
    const commands = [
      "Ask me about your schedule or calendar",
      "Set reminders with 'Set a reminder to call mom at 3 PM'",
      "Ask for the current time or date",
      "Ask about the weather",
      "Have a general conversation - I'm powered by AI!"
    ];
    
    const response = `I can help you with: ${commands.join(', ')}. Just speak naturally and I'll do my best to understand!`;
    this.speak(response);
    return response;
  }

  private async handleStopCommand(matches: RegExpMatchArray, fullCommand: string): Promise<string> {
    if (this.synthesis) {
      this.synthesis.cancel();
    }
    return "Stopped.";
  }

  private async handleCancelCommand(matches: RegExpMatchArray, fullCommand: string): Promise<string> {
    const response = "Okay, cancelled.";
    this.speak(response);
    return response;
  }

  private async handleWeatherQuery(matches: RegExpMatchArray, fullCommand: string): Promise<string> {
    const response = "I would check the weather for you, but weather integration isn't implemented yet. This would typically provide current conditions and forecasts.";
    this.speak(response);
    return response;
  }

  public speak(text: string): void {
    if (!this.synthesis) return;

    this.synthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    if (this.preferredVoice) {
      utterance.voice = this.preferredVoice;
    }
    utterance.lang = 'en-US';
    utterance.pitch = 1;
    utterance.rate = 1;
    utterance.volume = 1;

    this.synthesis.speak(utterance);
  }

  public toggleListening(): boolean {
    if (!this.recognition) {
      this.speak("Speech recognition is not supported in your browser.");
      return false;
    }

    this.isListening = !this.isListening;

    if (this.isListening) {
      this.recognition.start();
      this.speak("Voice recognition activated. How can I help?");
    } else {
      this.recognition.stop();
      this.speak("Voice recognition stopped.");
    }

    return this.isListening;
  }

  public isActive(): boolean {
    return this.isListening;
  }

  public getCommandSuggestions(): string[] {
    return this.commandRoutes.map(route => route.description);
  }

  public clearContext(): void {
    this.conversationContext = [];
  }

  public getContext(): string[] {
    return [...this.conversationContext];
  }

  public getAIConversationHistory() {
    return aiManager.getConversationHistory();
  }

  public getAIContextSummary(): string {
    return aiManager.getContextSummary();
  }

  public clearAIHistory(): void {
    aiManager.clearHistory();
  }

  public async processSpeechFile(audioFile: File): Promise<string> {
    try {
      // Validate file type
      if (!audioFile.type.startsWith('audio/')) {
        throw new Error('Invalid file type. Please upload an audio file.');
      }

      // Convert audio file to base64 for processing
      const audioData = await this.convertAudioToBase64(audioFile);
      
      // For now, we'll use a mock implementation since browser speech recognition
      // doesn't directly support file input. In production, this would connect
      // to a speech-to-text service like Google Cloud Speech-to-Text
      const transcript = await this.processAudioWithMockService(audioData, audioFile);
      
      // Process the transcript as a voice command
      if (transcript) {
        const response = await this.handleCommand(transcript);
        
        // Dispatch events for UI updates
        window.dispatchEvent(new CustomEvent('transcript-update', {
          detail: { text: transcript, interim: false, confidence: 0.9 }
        }));
        
        window.dispatchEvent(new CustomEvent('assistant-response', {
          detail: response
        }));
        
        return transcript;
      }
      
      return "No speech detected in the audio file.";
    } catch (error) {
      console.error('Audio file processing error:', error);
      throw new Error(`Failed to process audio file: ${error.message}`);
    }
  }

  private async convertAudioToBase64(audioFile: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          resolve(reader.result.split(',')[1]); // Remove data:audio/...;base64, prefix
        } else {
          reject(new Error('Failed to convert audio to base64'));
        }
      };
      reader.onerror = () => reject(new Error('Failed to read audio file'));
      reader.readAsDataURL(audioFile);
    });
  }

  private async processAudioWithMockService(audioData: string, audioFile: File): Promise<string> {
    // Mock implementation - in production, this would call a real speech-to-text API
    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Mock transcripts based on file characteristics for demo purposes
    const mockTranscripts = [
      "What's on my schedule today?",
      "Schedule a meeting with John at 3 PM tomorrow",
      "Set a reminder to call mom at 5 PM",
      "What time is it?",
      "Check my calendar for conflicts",
      "Help me prepare for my next meeting"
    ];
    
    // Use file size or name to determine mock response for consistency
    const index = audioFile.size % mockTranscripts.length;
    return mockTranscripts[index];
  }

  public async processAudioBuffer(audioBuffer: ArrayBuffer): Promise<string> {
    try {
      // Convert ArrayBuffer to Blob
      const audioBlob = new Blob([audioBuffer], { type: 'audio/wav' });
      const audioFile = new File([audioBlob], 'recorded-audio.wav', { type: 'audio/wav' });
      
      return await this.processSpeechFile(audioFile);
    } catch (error) {
      console.error('Audio buffer processing error:', error);
      throw error;
    }
  }

  private categorizeCommand(command: string): 'task' | 'calendar' | 'communication' | 'system' | 'break' {
    const commandLower = command.toLowerCase();
    
    if (commandLower.includes('task') || commandLower.includes('todo') || commandLower.includes('remind')) {
      return 'task';
    }
    if (commandLower.includes('schedule') || commandLower.includes('meeting') || commandLower.includes('calendar')) {
      return 'calendar';
    }
    if (commandLower.includes('email') || commandLower.includes('message') || commandLower.includes('call')) {
      return 'communication';
    }
    if (commandLower.includes('break') || commandLower.includes('rest') || commandLower.includes('pause')) {
      return 'break';
    }
    
    return 'system';
  }

  private assessUserEnergyFromCommand(command: string): 'high' | 'medium' | 'low' {
    const commandLower = command.toLowerCase();
    
    // High energy indicators
    if (commandLower.includes('let\'s') || commandLower.includes('excited') || commandLower.includes('ready')) {
      return 'high';
    }
    
    // Low energy indicators
    if (commandLower.includes('tired') || commandLower.includes('slow') || commandLower.includes('later')) {
      return 'low';
    }
    
    // Time-based assessment
    const hour = new Date().getHours();
    if (hour >= 9 && hour <= 11) return 'high'; // Morning peak
    if (hour >= 14 && hour <= 16) return 'high'; // Afternoon peak
    if (hour <= 7 || hour >= 22) return 'low'; // Early/late hours
    
    return 'medium';
  }

  private assessFocusFromCommand(command: string): number {
    const commandLower = command.toLowerCase();
    
    // Complex commands indicate higher focus
    if (commandLower.length > 50) return 8;
    if (commandLower.includes('analyze') || commandLower.includes('plan') || commandLower.includes('optimize')) return 9;
    if (commandLower.includes('simple') || commandLower.includes('quick')) return 6;
    if (commandLower.includes('help') || commandLower.includes('what')) return 4;
    
    return 7; // Default focus level
  }

  private assessProductivityFromCommand(command: string): number {
    const commandLower = command.toLowerCase();
    
    // High productivity commands
    if (commandLower.includes('schedule') || commandLower.includes('plan') || commandLower.includes('organize')) {
      return 8;
    }
    
    // Medium productivity commands
    if (commandLower.includes('reminder') || commandLower.includes('check') || commandLower.includes('review')) {
      return 6;
    }
    
    // Low productivity commands
    if (commandLower.includes('weather') || commandLower.includes('time') || commandLower.includes('help')) {
      return 4;
    }
    
    return 7; // Default productivity rating
  }
}

export const voiceAssistant = new VoiceAssistant();