
export interface WebSocketMessage {
  type: 'sync' | 'notification' | 'analytics' | 'task_update' | 'calendar_update' | 'ai_response' | 'system';
  payload: any;
  timestamp: number;
  userId?: string;
  sessionId: string;
}

export interface ConnectionStatus {
  connected: boolean;
  reconnecting: boolean;
  lastConnected?: Date;
  connectionAttempts: number;
}

class WebSocketService {
  private ws: WebSocket | null = null;
  private connectionStatus: ConnectionStatus = {
    connected: false,
    reconnecting: false,
    connectionAttempts: 0
  };
  private messageHandlers: Map<string, Function[]> = new Map();
  private reconnectTimeout: NodeJS.Timeout | null = null;
  private heartbeatInterval: NodeJS.Timeout | null = null;
  private sessionId: string;
  private userId: string | null = null;

  constructor() {
    this.sessionId = this.generateSessionId();
    this.setupEventListeners();
  }

  // Connection Management
  public connect(userId?: string): Promise<boolean> {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      return Promise.resolve(true);
    }

    this.userId = userId || null;
    
    return new Promise((resolve, reject) => {
      try {
        const wsUrl = this.getWebSocketUrl();
        this.ws = new WebSocket(wsUrl);

        this.ws.onopen = () => {
          console.log('WebSocket connected');
          this.connectionStatus = {
            connected: true,
            reconnecting: false,
            lastConnected: new Date(),
            connectionAttempts: 0
          };
          
          this.startHeartbeat();
          this.authenticate();
          this.emit('connection', { status: 'connected' });
          resolve(true);
        };

        this.ws.onmessage = (event) => {
          try {
            const message: WebSocketMessage = JSON.parse(event.data);
            this.handleMessage(message);
          } catch (error) {
            console.error('Failed to parse WebSocket message:', error);
          }
        };

        this.ws.onclose = (event) => {
          console.log('WebSocket disconnected:', event.code, event.reason);
          this.connectionStatus.connected = false;
          this.stopHeartbeat();
          this.emit('disconnect', { code: event.code, reason: event.reason });
          
          if (!event.wasClean) {
            this.scheduleReconnect();
          }
        };

        this.ws.onerror = (error) => {
          console.error('WebSocket error:', error);
          this.emit('error', error);
          reject(error);
        };

      } catch (error) {
        console.error('Failed to create WebSocket connection:', error);
        reject(error);
      }
    });
  }

  public disconnect(): void {
    if (this.reconnectTimeout) {
      clearTimeout(this.reconnectTimeout);
    }
    
    this.stopHeartbeat();
    
    if (this.ws) {
      this.ws.close(1000, 'Client disconnect');
      this.ws = null;
    }
    
    this.connectionStatus.connected = false;
  }

  // Message Handling
  public send(type: WebSocketMessage['type'], payload: any): boolean {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      console.warn('WebSocket not connected, message queued');
      this.queueMessage(type, payload);
      return false;
    }

    const message: WebSocketMessage = {
      type,
      payload,
      timestamp: Date.now(),
      userId: this.userId || undefined,
      sessionId: this.sessionId
    };

    try {
      this.ws.send(JSON.stringify(message));
      return true;
    } catch (error) {
      console.error('Failed to send WebSocket message:', error);
      return false;
    }
  }

  public on(eventType: string, handler: Function): void {
    if (!this.messageHandlers.has(eventType)) {
      this.messageHandlers.set(eventType, []);
    }
    this.messageHandlers.get(eventType)!.push(handler);
  }

  public off(eventType: string, handler: Function): void {
    const handlers = this.messageHandlers.get(eventType);
    if (handlers) {
      const index = handlers.indexOf(handler);
      if (index > -1) {
        handlers.splice(index, 1);
      }
    }
  }

  private emit(eventType: string, data: any): void {
    const handlers = this.messageHandlers.get(eventType);
    if (handlers) {
      handlers.forEach(handler => {
        try {
          handler(data);
        } catch (error) {
          console.error(`Error in WebSocket event handler for ${eventType}:`, error);
        }
      });
    }
  }

  private handleMessage(message: WebSocketMessage): void {
    // Handle system messages
    if (message.type === 'system') {
      this.handleSystemMessage(message);
      return;
    }

    // Emit specific message type
    this.emit(message.type, message.payload);
    
    // Emit general message event
    this.emit('message', message);

    // Handle specific message types
    switch (message.type) {
      case 'sync':
        this.handleSyncMessage(message);
        break;
      case 'notification':
        this.handleNotificationMessage(message);
        break;
      case 'analytics':
        this.handleAnalyticsMessage(message);
        break;
      case 'task_update':
        this.handleTaskUpdate(message);
        break;
      case 'calendar_update':
        this.handleCalendarUpdate(message);
        break;
      case 'ai_response':
        this.handleAIResponse(message);
        break;
    }
  }

  private handleSystemMessage(message: WebSocketMessage): void {
    const { payload } = message;
    
    switch (payload.action) {
      case 'ping':
        this.send('system', { action: 'pong', timestamp: Date.now() });
        break;
      case 'auth_required':
        this.authenticate();
        break;
      case 'rate_limit':
        console.warn('Rate limit exceeded:', payload);
        this.emit('rate_limit', payload);
        break;
    }
  }

  private handleSyncMessage(message: WebSocketMessage): void {
    // Trigger data synchronization
    window.dispatchEvent(new CustomEvent('auramind_sync', {
      detail: message.payload
    }));
  }

  private handleNotificationMessage(message: WebSocketMessage): void {
    // Show notification
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(message.payload.title, {
        body: message.payload.body,
        icon: '/favicon.svg'
      });
    }
  }

  private handleAnalyticsMessage(message: WebSocketMessage): void {
    // Update analytics in real-time
    window.dispatchEvent(new CustomEvent('auramind_analytics_update', {
      detail: message.payload
    }));
  }

  private handleTaskUpdate(message: WebSocketMessage): void {
    window.dispatchEvent(new CustomEvent('auramind_task_update', {
      detail: message.payload
    }));
  }

  private handleCalendarUpdate(message: WebSocketMessage): void {
    window.dispatchEvent(new CustomEvent('auramind_calendar_update', {
      detail: message.payload
    }));
  }

  private handleAIResponse(message: WebSocketMessage): void {
    window.dispatchEvent(new CustomEvent('auramind_ai_response', {
      detail: message.payload
    }));
  }

  // Connection Utilities
  private getWebSocketUrl(): string {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    return `${protocol}//${host}/ws`;
  }

  private authenticate(): void {
    if (this.userId) {
      this.send('system', {
        action: 'authenticate',
        userId: this.userId,
        sessionId: this.sessionId
      });
    }
  }

  private scheduleReconnect(): void {
    if (this.connectionStatus.reconnecting) return;

    this.connectionStatus.reconnecting = true;
    this.connectionStatus.connectionAttempts++;

    const delay = Math.min(1000 * Math.pow(2, this.connectionStatus.connectionAttempts - 1), 30000);
    
    console.log(`Reconnecting in ${delay}ms (attempt ${this.connectionStatus.connectionAttempts})`);
    
    this.reconnectTimeout = setTimeout(() => {
      this.connect(this.userId || undefined)
        .catch(() => {
          if (this.connectionStatus.connectionAttempts < 5) {
            this.scheduleReconnect();
          } else {
            console.error('Max reconnection attempts reached');
            this.connectionStatus.reconnecting = false;
          }
        });
    }, delay);
  }

  private startHeartbeat(): void {
    this.heartbeatInterval = setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.send('system', { action: 'ping', timestamp: Date.now() });
      }
    }, 30000); // 30 seconds
  }

  private stopHeartbeat(): void {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
  }

  private generateSessionId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private queueMessage(type: WebSocketMessage['type'], payload: any): void {
    // Store message for retry when connection is restored
    const queueKey = 'auramind_ws_queue';
    const queue = JSON.parse(localStorage.getItem(queueKey) || '[]');
    
    queue.push({
      type,
      payload,
      timestamp: Date.now()
    });

    // Keep only last 50 messages
    if (queue.length > 50) {
      queue.splice(0, queue.length - 50);
    }

    localStorage.setItem(queueKey, JSON.stringify(queue));
  }

  private setupEventListeners(): void {
    // Handle page visibility changes
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible' && !this.connectionStatus.connected) {
        this.connect(this.userId || undefined);
      }
    });

    // Handle online/offline events
    window.addEventListener('online', () => {
      if (!this.connectionStatus.connected) {
        this.connect(this.userId || undefined);
      }
    });

    window.addEventListener('offline', () => {
      this.disconnect();
    });
  }

  // Public API
  public getConnectionStatus(): ConnectionStatus {
    return { ...this.connectionStatus };
  }

  public isConnected(): boolean {
    return this.connectionStatus.connected;
  }

  public sendSync(data: any): boolean {
    return this.send('sync', data);
  }

  public sendNotification(title: string, body: string, data?: any): boolean {
    return this.send('notification', { title, body, data });
  }

  public sendAnalytics(data: any): boolean {
    return this.send('analytics', data);
  }

  public sendTaskUpdate(taskId: string, update: any): boolean {
    return this.send('task_update', { taskId, update });
  }

  public sendCalendarUpdate(eventId: string, update: any): boolean {
    return this.send('calendar_update', { eventId, update });
  }
}

export const wsService = new WebSocketService();
