
import React, { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Upload, Loader2, FileAudio, X } from 'lucide-react';
import { voiceAssistant } from '../lib/voiceAssistant';

interface AudioUploadProps {
  onTranscript?: (transcript: string) => void;
  onError?: (error: string) => void;
}

const AudioUpload: React.FC<AudioUploadProps> = ({ onTranscript, onError }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [transcript, setTranscript] = useState<string>('');

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('audio/')) {
      const errorMsg = 'Please select an audio file (MP3, WAV, M4A, etc.)';
      onError?.(errorMsg);
      return;
    }

    setUploadedFile(file);
    setIsProcessing(true);
    setTranscript('');

    try {
      const result = await voiceAssistant.processSpeechFile(file);
      setTranscript(result);
      onTranscript?.(result);
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Failed to process audio file';
      onError?.(errorMsg);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    const file = event.dataTransfer.files?.[0];
    if (file && fileInputRef.current) {
      const dataTransfer = new DataTransfer();
      dataTransfer.items.add(file);
      fileInputRef.current.files = dataTransfer.files;
      fileInputRef.current.dispatchEvent(new Event('change', { bubbles: true }));
    }
  };

  const clearFile = () => {
    setUploadedFile(null);
    setTranscript('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center hover:border-primary-500 transition-colors"
        onDrop={handleDrop}
        onDragOver={(e) => e.preventDefault()}
      >
        {!uploadedFile ? (
          <>
            <FileAudio className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
              Upload Audio File
            </h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
              Drop an audio file here or click to browse
            </p>
            <input
              ref={fileInputRef}
              type="file"
              accept="audio/*"
              onChange={handleFileSelect}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isProcessing}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="animate-spin -ml-1 mr-2 h-4 w-4" />
                  Processing...
                </>
              ) : (
                <>
                  <Upload className="-ml-1 mr-2 h-4 w-4" />
                  Choose File
                </>
              )}
            </button>
          </>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between bg-gray-50 dark:bg-gray-700 rounded-lg p-3">
              <div className="flex items-center space-x-3">
                <FileAudio className="h-6 w-6 text-primary-600" />
                <div className="text-left">
                  <p className="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {uploadedFile.name}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {(uploadedFile.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>
              </div>
              <button
                onClick={clearFile}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {isProcessing && (
              <div className="flex items-center justify-center space-x-2">
                <Loader2 className="animate-spin h-5 w-5 text-primary-600" />
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  Processing audio...
                </span>
              </div>
            )}

            {transcript && (
              <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4">
                <h4 className="text-sm font-medium text-green-800 dark:text-green-200 mb-2">
                  Transcript:
                </h4>
                <p className="text-sm text-green-700 dark:text-green-300">
                  {transcript}
                </p>
              </div>
            )}
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default AudioUpload;
