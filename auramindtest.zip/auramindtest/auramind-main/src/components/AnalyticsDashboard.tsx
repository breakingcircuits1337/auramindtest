
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  TrendingUp, 
  TrendingDown, 
  Brain, 
  Clock, 
  Target, 
  Zap,
  BarChart3,
  PieChart,
  Activity,
  Lightbulb,
  Calendar,
  AlertCircle
} from 'lucide-react';
import { analyticsEngine, ProductivityMetrics, PerformanceTrend, PredictiveInsight } from '../lib/analytics';

interface AnalyticsDashboardProps {
  timeframe?: 'week' | 'month' | 'quarter';
  onClose?: () => void;
}

const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({ 
  timeframe = 'week',
  onClose 
}) => {
  const [metrics, setMetrics] = useState<ProductivityMetrics | null>(null);
  const [trends, setTrends] = useState<PerformanceTrend[]>([]);
  const [insights, setInsights] = useState<PredictiveInsight[]>([]);
  const [activeTab, setActiveTab] = useState<'overview' | 'patterns' | 'predictions'>('overview');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAnalyticsData();
  }, [timeframe]);

  const loadAnalyticsData = async () => {
    setLoading(true);
    try {
      const productivityMetrics = analyticsEngine.calculateProductivityMetrics(timeframe);
      const performanceTrends = analyticsEngine.analyzePerformanceTrends(timeframe);
      const predictiveInsights = analyticsEngine.generatePredictiveInsights();
      
      setMetrics(productivityMetrics);
      setTrends(performanceTrends);
      setInsights(predictiveInsights);
    } catch (error) {
      console.error('Failed to load analytics data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getScoreColor = (score: number): string => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getTrendIcon = (trend: 'up' | 'down' | 'stable') => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="w-4 h-4 text-green-600" />;
      case 'down':
        return <TrendingDown className="w-4 h-4 text-red-600" />;
      default:
        return <div className="w-4 h-4 bg-gray-400 rounded-full" />;
    }
  };

  const formatPercentage = (value: number): string => {
    return `${Math.round(value)}%`;
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg p-8 flex items-center space-x-4">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
          <span className="text-lg">Analyzing your productivity data...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="bg-white rounded-xl shadow-2xl max-w-6xl w-full max-h-[90vh] overflow-hidden"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-primary-600 to-primary-800 text-white p-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-2xl font-bold mb-2">Analytics Dashboard</h2>
              <p className="text-primary-100">
                Insights from your {timeframe} productivity data
              </p>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:text-primary-200 transition-colors"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          
          {/* Tab Navigation */}
          <div className="flex space-x-4 mt-4">
            {[
              { id: 'overview', label: 'Overview', icon: BarChart3 },
              { id: 'patterns', label: 'Patterns', icon: Brain },
              { id: 'predictions', label: 'Predictions', icon: Lightbulb }
            ].map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id as any)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                  activeTab === id 
                    ? 'bg-white text-primary-600' 
                    : 'text-primary-100 hover:text-white hover:bg-primary-700'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-160px)]">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Key Metrics */}
              {metrics && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <Target className="w-8 h-8 text-blue-600" />
                      <span className={`text-2xl font-bold ${getScoreColor(metrics.overall.score)}`}>
                        {formatPercentage(metrics.overall.score)}
                      </span>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-800">Overall Score</h3>
                    <p className="text-sm text-gray-600">
                      {metrics.overall.trend === 'improving' && '↗️ Improving'}
                      {metrics.overall.trend === 'declining' && '↘️ Declining'}
                      {metrics.overall.trend === 'stable' && '➖ Stable'}
                    </p>
                  </div>

                  <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <Clock className="w-8 h-8 text-green-600" />
                      <span className="text-2xl font-bold text-green-600">
                        {formatPercentage(metrics.timeManagement.completionRate)}
                      </span>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-800">Task Completion</h3>
                    <p className="text-sm text-gray-600">
                      {metrics.timeManagement.tasksCompleted} of {metrics.timeManagement.tasksPlanned} tasks
                    </p>
                  </div>

                  <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <Brain className="w-8 h-8 text-purple-600" />
                      <span className="text-2xl font-bold text-purple-600">
                        {metrics.focusMetrics.deepWorkSessions}
                      </span>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-800">Deep Work Sessions</h3>
                    <p className="text-sm text-gray-600">
                      Avg {Math.round(metrics.focusMetrics.averageFocusSession)}min each
                    </p>
                  </div>

                  <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-6 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <Zap className="w-8 h-8 text-orange-600" />
                      <span className="text-2xl font-bold text-orange-600">
                        {metrics.energyPatterns.peakHours.length}
                      </span>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-800">Peak Hours</h3>
                    <p className="text-sm text-gray-600">
                      {metrics.energyPatterns.peakHours.join(', ')}
                    </p>
                  </div>
                </div>
              )}

              {/* Performance Trends */}
              <div className="bg-white border border-gray-200 rounded-lg p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                  <Activity className="w-5 h-5 mr-2 text-primary-600" />
                  Performance Trends
                </h3>
                <div className="space-y-4">
                  {trends.map((trend, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        {getTrendIcon(trend.trend)}
                        <div>
                          <h4 className="font-semibold text-gray-800">{trend.metric}</h4>
                          <p className="text-sm text-gray-600">
                            {trend.changeRate > 0 ? '+' : ''}{trend.changeRate.toFixed(1)}% change
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold text-gray-800">
                          {trend.projectedValue.toFixed(1)}
                        </div>
                        <div className="text-sm text-gray-500">Projected</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'patterns' && (
            <div className="space-y-6">
              <div className="bg-white border border-gray-200 rounded-lg p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-4">
                  Discovered Behavior Patterns
                </h3>
                <div className="space-y-4">
                  {analyticsEngine.getBehaviorInsights().map((pattern, index) => (
                    <div key={index} className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border-l-4 border-blue-500">
                      <p className="text-gray-800">{pattern}</p>
                    </div>
                  ))}
                </div>
              </div>

              {metrics && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white border border-gray-200 rounded-lg p-6">
                    <h4 className="text-lg font-semibold text-gray-800 mb-4">Energy Patterns</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Peak Hours:</span>
                        <span className="font-semibold">
                          {metrics.energyPatterns.peakHours.join(', ')}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Low Energy:</span>
                        <span className="font-semibold">
                          {metrics.energyPatterns.lowEnergyPeriods.join(', ')}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Recovery Time:</span>
                        <span className="font-semibold">
                          {metrics.energyPatterns.recoveryTime} min
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white border border-gray-200 rounded-lg p-6">
                    <h4 className="text-lg font-semibold text-gray-800 mb-4">Focus Patterns</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Deep Work Sessions:</span>
                        <span className="font-semibold">
                          {metrics.focusMetrics.deepWorkSessions}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Avg Session:</span>
                        <span className="font-semibold">
                          {Math.round(metrics.focusMetrics.averageFocusSession)} min
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Flow States:</span>
                        <span className="font-semibold">
                          {metrics.focusMetrics.flowStateFrequency}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'predictions' && (
            <div className="space-y-6">
              <div className="bg-white border border-gray-200 rounded-lg p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                  <Lightbulb className="w-5 h-5 mr-2 text-yellow-500" />
                  Predictive Insights & Recommendations
                </h3>
                <div className="space-y-4">
                  {insights.map((insight, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <div className={`w-3 h-3 rounded-full ${
                            insight.type === 'schedule_optimization' ? 'bg-blue-500' :
                            insight.type === 'energy_management' ? 'bg-orange-500' :
                            insight.type === 'task_prioritization' ? 'bg-green-500' :
                            'bg-purple-500'
                          }`}></div>
                          <span className="text-sm font-semibold text-gray-600 uppercase">
                            {insight.type.replace('_', ' ')}
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-gray-500">
                            {Math.round(insight.confidence * 100)}% confidence
                          </span>
                          <span className="text-sm text-green-600">
                            +{Math.round(insight.expectedImpact * 100)}% impact
                          </span>
                        </div>
                      </div>
                      <p className="text-gray-800">{insight.recommendation}</p>
                      <div className="flex items-center mt-2 text-sm text-gray-500">
                        <Calendar className="w-4 h-4 mr-1" />
                        Apply {insight.timeframe}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-gradient-to-r from-yellow-50 to-orange-50 border border-yellow-200 rounded-lg p-6">
                <div className="flex items-center mb-4">
                  <AlertCircle className="w-5 h-5 text-yellow-600 mr-2" />
                  <h4 className="text-lg font-semibold text-gray-800">Quick Recommendations</h4>
                </div>
                <div className="space-y-2">
                  {analyticsEngine.getPredictiveRecommendations().map((recommendation, index) => (
                    <div key={index} className="flex items-start space-x-2">
                      <div className="w-1.5 h-1.5 bg-yellow-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-gray-700">{recommendation}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-gray-50 px-6 py-4 border-t border-gray-200">
          <div className="flex justify-between items-center">
            <div className="text-sm text-gray-500">
              Data analyzed from {timeframe} of activity
            </div>
            <div className="flex space-x-3">
              <button
                onClick={() => {
                  const data = analyticsEngine.exportAnalyticsData();
                  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `auramind-analytics-${new Date().toISOString().split('T')[0]}.json`;
                  document.body.appendChild(a);
                  a.click();
                  document.body.removeChild(a);
                  URL.revokeObjectURL(url);
                }}
                className="px-4 py-2 text-sm text-gray-600 hover:text-gray-800 transition-colors"
              >
                Export Data
              </button>
              <button
                onClick={loadAnalyticsData}
                className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors"
              >
                Refresh
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default AnalyticsDashboard;
