import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import Technology from './components/Technology';
import UserStories from './components/UserStories';
import Roadmap from './components/Roadmap';
import Challenges from './components/Challenges';
import CTA from './components/CTA';
import Footer from './components/Footer';
import Pricing from './components/Pricing';
import ThemeProvider from './components/ThemeProvider';
import AIAssistant from './components/AIAssistant';
import TaskManager from './components/TaskManager';
import CommunicationHub from './components/CommunicationHub';
import CalendarIntegration from './components/CalendarIntegration';
import AnalyticsDashboard from './components/AnalyticsDashboard';
import UserProfile from './components/UserProfile';
import ErrorBoundary from './components/ErrorBoundary';
import EmailVerification from './components/EmailVerification';
import PasswordReset from './components/PasswordReset';
import { ENV_CONFIG } from './lib/env';
import { dbService } from './lib/database';
import { infrastructureManager } from './lib/infrastructure';
import { monitoringService } from './lib/monitoring';

function App() {
  const [envWarnings, setEnvWarnings] = useState<string[]>([]);
  const [currentView, setCurrentView] = useState('home');
  const [infrastructureStatus, setInfrastructureStatus] = useState<'initializing' | 'ready' | 'error'>('initializing');
  const [showProfile, setShowProfile] = useState(false);

  useEffect(() => {
    const initializeApp = async () => {
      try {
        // Check environment configuration
        const warnings = ENV_CONFIG.getWarnings();
        if (warnings.length > 0) {
          console.warn('Environment Configuration Warnings:', warnings);
          setEnvWarnings(warnings);
        }

        console.log('App initialized with environment warnings:', warnings);

        // Initialize infrastructure
        const infrastructureReady = await infrastructureManager.initialize();

        if (infrastructureReady) {
          setInfrastructureStatus('ready');
          console.log('Infrastructure initialized successfully');

          // Record successful initialization
          monitoringService.recordMetric({
            name: 'app.initialization.success',
            value: 1,
            timestamp: Date.now(),
            type: 'counter'
          });

        } else {
          setInfrastructureStatus('error');
          console.error('Infrastructure initialization failed');

          monitoringService.captureError({
            message: 'App infrastructure initialization failed',
            severity: 'high',
            context: { warnings }
          });
        }

      } catch (error) {
        setInfrastructureStatus('error');
        console.error('App initialization error:', error);

        monitoringService.captureError({
          message: 'App initialization error',
          severity: 'critical',
          context: { error: error.message }
        });
      }
    };

    initializeApp();

    // Set up infrastructure health monitoring
    const healthCheckInterval = setInterval(() => {
      const health = infrastructureManager.getHealthStatus();
      if (health && health.status === 'critical') {
        console.warn('Infrastructure health is critical:', health);
      }
    }, 60000); // Check every minute

    return () => {
      clearInterval(healthCheckInterval);
    };
  }, []);

  return (
    <ThemeProvider>
      <ErrorBoundary>
        <div className="min-h-screen bg-background">
          {envWarnings.length > 0 && (
            <div className="bg-warning-100 border-l-4 border-warning-500 p-4 mb-4">
              <div className="flex">
                <div className="ml-3">
                  <p className="text-sm text-warning-800">
                    <strong>Configuration Warning:</strong> Some features may not work properly:
                  </p>
                  <ul className="mt-1 text-sm text-warning-700 list-disc list-inside">
                    {envWarnings.map((warning, index) => (
                      <li key={index}>{warning}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}

          {infrastructureStatus === 'initializing' && (
            <div className="bg-blue-100 border-l-4 border-blue-500 p-4 mb-4">
              <div className="flex">
                <div className="ml-3">
                  <p className="text-sm text-blue-800">
                    <strong>Initializing:</strong> Setting up infrastructure services...
                  </p>
                </div>
              </div>
            </div>
          )}

          {infrastructureStatus === 'error' && (
            <div className="bg-red-100 border-l-4 border-red-500 p-4 mb-4">
              <div className="flex">
                <div className="ml-3">
                  <p className="text-sm text-red-800">
                    <strong>Infrastructure Error:</strong> Some services may not work properly. Using fallback mode.
                  </p>
                </div>
              </div>
            </div>
          )}

        <Navbar onProfileClick={() => setShowProfile(true)} />
        <Hero />
        <Features />
        <Technology />
        <UserStories />
        <Challenges />
        <Roadmap />
        <Pricing />
        <CTA />
        <Footer />
        <UserProfile isOpen={showProfile} onClose={() => setShowProfile(false)} />
      </div>
    </ErrorBoundary>
    </ThemeProvider>
  );
}

export default App;