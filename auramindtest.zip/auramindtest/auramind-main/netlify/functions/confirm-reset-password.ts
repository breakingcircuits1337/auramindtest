
import { Handler } from '@netlify/functions';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const { token, email, newPassword } = JSON.parse(event.body!);
    
    if (!token || !email || !newPassword) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Token, email, and new password are required' })
      };
    }

    if (newPassword.length < 6) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Password must be at least 6 characters long' })
      };
    }

    // Verify the reset token (in production, check against stored tokens in DB)
    const tokenData = Buffer.from(token, 'base64').toString();
    if (!tokenData.includes(email) || !tokenData.includes('reset')) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Invalid or expired reset token' })
      };
    }

    // Get user by email
    const { data: user, error: getUserError } = await supabase.auth.admin.getUserByEmail(email);
    
    if (getUserError || !user) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'User not found' })
      };
    }

    // Update user password
    const { error: updateError } = await supabase.auth.admin.updateUserById(
      user.user.id,
      { password: newPassword }
    );

    if (updateError) throw updateError;

    return {
      statusCode: 200,
      body: JSON.stringify({ 
        message: 'Password updated successfully'
      })
    };
  } catch (error: any) {
    console.error('Password reset confirmation error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        error: 'Failed to reset password',
        details: error.message
      })
    };
  }
};
