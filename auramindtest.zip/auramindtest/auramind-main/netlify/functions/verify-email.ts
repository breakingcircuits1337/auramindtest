
import { Handler } from '@netlify/functions';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const { token, email } = JSON.parse(event.body!);
    
    if (!token || !email) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Token and email are required' })
      };
    }

    // Verify the token (basic implementation - you might want to store tokens in DB)
    const expectedToken = Buffer.from(email + 'verification').toString('base64');
    
    if (token !== expectedToken) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Invalid verification token' })
      };
    }

    // Update user email verification status
    const { data: user, error: getUserError } = await supabase.auth.admin.getUserByEmail(email);
    
    if (getUserError || !user) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'User not found' })
      };
    }

    // Update user as verified
    const { error: updateError } = await supabase.auth.admin.updateUserById(
      user.user.id,
      { email_confirm: true }
    );

    if (updateError) throw updateError;

    return {
      statusCode: 200,
      body: JSON.stringify({ 
        message: 'Email verified successfully',
        verified: true 
      })
    };
  } catch (error: any) {
    console.error('Email verification error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        error: 'Failed to verify email',
        details: error.message
      })
    };
  }
};
