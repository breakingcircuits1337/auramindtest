import { Handler } from '@netlify/functions';
import sgMail from '@sendgrid/mail';

sgMail.setApiKey(process.env.SENDGRID_API_KEY!);

export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const { email } = JSON.parse(event.body!);

    if (!email) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Email is required' })
      };
    }

    // Generate verification token
    const verificationToken = Buffer.from(email + 'verification').toString('base64');

    // Create verification URL
    const verificationUrl = `${process.env.URL}/verify?token=${verificationToken}&email=${encodeURIComponent(email)}`;

    // Send welcome email with verification
    const msg = {
      to: email,
      from: 'noreply@auramind.app',
      subject: 'Welcome to AuraMind - Please Verify Your Email',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2>Welcome to AuraMind!</h2>
          <p>Your account has been created successfully. Please verify your email address to complete your registration.</p>
          <a href="${verificationUrl}" style="background-color: #4F46E5; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; margin: 20px 0;">
            Verify Email Address
          </a>
          <p>If you didn't create this account, please ignore this email.</p>
          <p>If the button doesn't work, copy and paste this link into your browser:</p>
          <p><a href="${verificationUrl}">${verificationUrl}</a></p>
        </div>
      `,
    };

    await sgMail.send(msg);

    return {
      statusCode: 200,
      body: JSON.stringify({ 
        message: 'Verification email sent',
        email 
      })
    };
  } catch (error: any) {
    console.error('Signup error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        error: 'Failed to process signup',
        details: error.message
      })
    };
  }
};