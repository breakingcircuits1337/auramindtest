
import { Handler } from '@netlify/functions';
import { google } from 'googleapis';

export const handler: Handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const { provider, accessToken, refreshToken, timeMin, timeMax } = JSON.parse(event.body || '{}');

    if (provider === 'google') {
      const oauth2Client = new google.auth.OAuth2(
        process.env.GOOGLE_CLIENT_ID,
        process.env.GOOGLE_CLIENT_SECRET
      );

      oauth2Client.setCredentials({
        access_token: accessToken,
        refresh_token: refreshToken
      });

      const calendar = google.calendar({ version: 'v3', auth: oauth2Client });

      const response = await calendar.events.list({
        calendarId: 'primary',
        timeMin: timeMin || new Date().toISOString(),
        timeMax: timeMax || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        maxResults: 50,
        singleEvents: true,
        orderBy: 'startTime'
      });

      const events = response.data.items?.map(event => ({
        id: `google_${event.id}`,
        title: event.summary || 'Untitled Event',
        description: event.description,
        start: new Date(event.start?.dateTime || event.start?.date || ''),
        end: new Date(event.end?.dateTime || event.end?.date || ''),
        location: event.location,
        attendees: event.attendees?.map(a => a.email) || [],
        isAllDay: !event.start?.dateTime,
        status: event.status === 'cancelled' ? 'cancelled' : 
                event.status === 'tentative' ? 'tentative' : 'confirmed',
        priority: 'medium',
        reminders: event.reminders?.overrides?.map(r => r.minutes) || [15],
        source: 'google'
      })) || [];

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ events })
      };
    }

    if (provider === 'microsoft') {
      const response = await fetch('https://graph.microsoft.com/v1.0/me/events', {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`Microsoft Graph API error: ${response.statusText}`);
      }

      const data = await response.json();
      
      const events = data.value?.map((event: any) => ({
        id: `microsoft_${event.id}`,
        title: event.subject || 'Untitled Event',
        description: event.bodyPreview,
        start: new Date(event.start?.dateTime),
        end: new Date(event.end?.dateTime),
        location: event.location?.displayName,
        attendees: event.attendees?.map((a: any) => a.emailAddress?.address) || [],
        isAllDay: event.isAllDay,
        status: event.isCancelled ? 'cancelled' : 
                event.responseStatus?.response === 'tentativelyAccepted' ? 'tentative' : 'confirmed',
        priority: event.importance === 'high' ? 'high' : 
                 event.importance === 'low' ? 'low' : 'medium',
        reminders: [15],
        source: 'microsoft'
      })) || [];

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ events })
      };
    }

    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: 'Unsupported provider' })
    };

  } catch (error) {
    console.error('Calendar sync error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Calendar sync failed' })
    };
  }
};
