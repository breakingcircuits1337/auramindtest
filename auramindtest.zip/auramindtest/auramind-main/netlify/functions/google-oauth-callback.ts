
import { Handler } from '@netlify/functions';

export const handler: Handler = async (event) => {
  const { code, error } = event.queryStringParameters || {};

  if (error) {
    return {
      statusCode: 302,
      headers: {
        Location: `${process.env.URL}?auth_error=${encodeURIComponent(error)}`
      }
    };
  }

  if (code) {
    return {
      statusCode: 302,
      headers: {
        Location: `${process.env.URL}?auth_code=${encodeURIComponent(code)}`
      }
    };
  }

  return {
    statusCode: 400,
    body: 'Missing authorization code'
  };
};
