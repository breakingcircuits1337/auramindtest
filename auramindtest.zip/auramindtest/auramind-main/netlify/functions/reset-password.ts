
import { Handler } from '@netlify/functions';
import { createClient } from '@supabase/supabase-js';
import sgMail from '@sendgrid/mail';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

sgMail.setApiKey(process.env.SENDGRID_API_KEY!);

export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const { email } = JSON.parse(event.body!);
    
    if (!email) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Email is required' })
      };
    }

    // Check if user exists
    const { data: user, error: getUserError } = await supabase.auth.admin.getUserByEmail(email);
    
    if (getUserError || !user) {
      // Don't reveal if email exists or not for security
      return {
        statusCode: 200,
        body: JSON.stringify({ 
          message: 'If the email exists, a password reset link has been sent'
        })
      };
    }

    // Generate reset token
    const resetToken = Buffer.from(email + Date.now().toString() + 'reset').toString('base64');
    const expiresAt = new Date(Date.now() + 3600000); // 1 hour from now
    
    // Create reset URL
    const resetUrl = `${process.env.URL}/reset-password?token=${resetToken}&email=${encodeURIComponent(email)}`;

    // Send password reset email
    const msg = {
      to: email,
      from: 'noreply@auramind.app',
      subject: 'Reset Your AuraMind Password',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2>Password Reset Request</h2>
          <p>You requested to reset your password for your AuraMind account.</p>
          <p>Click the link below to reset your password:</p>
          <a href="${resetUrl}" style="background-color: #4F46E5; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
            Reset Password
          </a>
          <p>This link will expire in 1 hour.</p>
          <p>If you didn't request this password reset, please ignore this email.</p>
        </div>
      `,
    };

    await sgMail.send(msg);

    // In a production app, you'd store the reset token in your database
    // For now, we'll include it in the response for testing

    return {
      statusCode: 200,
      body: JSON.stringify({ 
        message: 'If the email exists, a password reset link has been sent',
        resetToken: resetToken, // Remove this in production
        expiresAt: expiresAt.toISOString()
      })
    };
  } catch (error: any) {
    console.error('Password reset error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        error: 'Failed to process password reset request',
        details: error.message
      })
    };
  }
};
