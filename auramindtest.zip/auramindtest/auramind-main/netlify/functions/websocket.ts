
import { Handler, HandlerEvent, HandlerContext } from '@netlify/functions';

interface WebSocketMessage {
  type: 'sync' | 'notification' | 'analytics' | 'task_update' | 'calendar_update' | 'ai_response' | 'system';
  payload: any;
  timestamp: number;
  userId?: string;
  sessionId: string;
}

// In-memory store for connections (in production, use Redis or similar)
const connections = new Map<string, {
  userId?: string;
  sessionId: string;
  connectionTime: number;
  lastActivity: number;
}>();

const handler: Handler = async (event: HandlerEvent, context: HandlerContext) => {
  const { headers, body, httpMethod, queryStringParameters } = event;
  
  // Handle WebSocket upgrade request
  if (headers.upgrade === 'websocket') {
    return {
      statusCode: 101,
      headers: {
        'Upgrade': 'websocket',
        'Connection': 'Upgrade',
        'Sec-WebSocket-Accept': generateWebSocketAccept(headers['sec-websocket-key']),
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
      }
    };
  }

  // Handle HTTP requests for WebSocket management
  if (httpMethod === 'POST') {
    try {
      const message: WebSocketMessage = JSON.parse(body || '{}');
      
      // Route message based on type
      switch (message.type) {
        case 'sync':
          return await handleSyncMessage(message);
        case 'notification':
          return await handleNotificationMessage(message);
        case 'analytics':
          return await handleAnalyticsMessage(message);
        case 'system':
          return await handleSystemMessage(message);
        default:
          return await broadcastMessage(message);
      }
      
    } catch (error) {
      console.error('WebSocket function error:', error);
      return {
        statusCode: 500,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({ error: 'Internal server error' })
      };
    }
  }

  // Handle connection status requests
  if (httpMethod === 'GET') {
    const stats = {
      activeConnections: connections.size,
      timestamp: Date.now()
    };

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify(stats)
    };
  }

  return {
    statusCode: 405,
    headers: {
      'Access-Control-Allow-Origin': '*'
    },
    body: JSON.stringify({ error: 'Method not allowed' })
  };
};

async function handleSyncMessage(message: WebSocketMessage) {
  // Handle data synchronization
  const { userId, payload } = message;
  
  // In a real implementation, you would:
  // 1. Validate the user has permission to sync this data
  // 2. Update the database with the new data
  // 3. Broadcast changes to other connected clients for the same user
  
  console.log('Sync message received:', { userId, type: payload.type });
  
  // Broadcast to other sessions of the same user
  await broadcastToUser(userId, {
    ...message,
    type: 'sync',
    timestamp: Date.now()
  });

  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    },
    body: JSON.stringify({ success: true, synced: true })
  };
}

async function handleNotificationMessage(message: WebSocketMessage) {
  // Handle push notifications
  const { userId, payload } = message;
  
  // Send notification to user's devices
  await broadcastToUser(userId, {
    type: 'notification',
    payload: {
      title: payload.title,
      body: payload.body,
      timestamp: Date.now()
    },
    timestamp: Date.now(),
    sessionId: 'server'
  });

  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    },
    body: JSON.stringify({ success: true, notificationSent: true })
  };
}

async function handleAnalyticsMessage(message: WebSocketMessage) {
  // Handle analytics data
  const { userId, payload } = message;
  
  // In production, you would store analytics data in a database
  console.log('Analytics data received:', { userId, data: payload });
  
  // Optionally broadcast aggregated analytics to admin users
  // await broadcastToAdmins(analyticsUpdate);

  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    },
    body: JSON.stringify({ success: true, analyticsRecorded: true })
  };
}

async function handleSystemMessage(message: WebSocketMessage) {
  const { payload, sessionId } = message;
  
  switch (payload.action) {
    case 'authenticate':
      // Register connection
      connections.set(sessionId, {
        userId: payload.userId,
        sessionId: payload.sessionId,
        connectionTime: Date.now(),
        lastActivity: Date.now()
      });
      break;
      
    case 'ping':
      // Update last activity
      const connection = connections.get(sessionId);
      if (connection) {
        connection.lastActivity = Date.now();
      }
      
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({ 
          type: 'system', 
          payload: { action: 'pong', timestamp: Date.now() } 
        })
      };
      
    case 'disconnect':
      connections.delete(sessionId);
      break;
  }

  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    },
    body: JSON.stringify({ success: true })
  };
}

async function broadcastMessage(message: WebSocketMessage) {
  // Broadcast to all connected clients
  // In production, you would use a message queue or pub/sub system
  
  console.log('Broadcasting message:', message.type);
  
  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    },
    body: JSON.stringify({ success: true, broadcasted: true })
  };
}

async function broadcastToUser(userId: string | undefined, message: any) {
  if (!userId) return;
  
  // Find all connections for this user
  const userConnections = Array.from(connections.entries())
    .filter(([_, conn]) => conn.userId === userId);
  
  console.log(`Broadcasting to user ${userId}:`, userConnections.length, 'connections');
  
  // In production, you would send the message to each connection
  // For now, just log it
}

function generateWebSocketAccept(key: string): string {
  // WebSocket key acceptance algorithm
  const crypto = require('crypto');
  const WEBSOCKET_MAGIC_STRING = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
  
  return crypto
    .createHash('sha1')
    .update(key + WEBSOCKET_MAGIC_STRING)
    .digest('base64');
}

// Cleanup old connections periodically
setInterval(() => {
  const now = Date.now();
  const maxAge = 5 * 60 * 1000; // 5 minutes
  
  for (const [sessionId, connection] of connections.entries()) {
    if (now - connection.lastActivity > maxAge) {
      connections.delete(sessionId);
    }
  }
}, 60000); // Clean up every minute

export { handler };
